"""
Full AI Inference Pipeline
Detect → Clean → Classify → Prioritize → Route → Return result
"""

import sys
import os

# Ensure ai_module sub-packages are importable
_BASE = os.path.dirname(os.path.dirname(__file__))
for sub in ("language_detection", "preprocessing", "model"):
    p = os.path.join(_BASE, sub)
    if p not in sys.path:
        sys.path.insert(0, p)

from detector   import detect_language
from text_cleaner import clean_text, extract_keywords
from classifier import classify, classify_with_xlm, DEPT_MAP


def _simple_translate_hint(text: str, lang: str) -> str | None:
    """
    Returns a rough English hint for non-English text.
    (Placeholder — replace with DeepL/Google Translate API in production.)
    """
    if lang in ("en", "hinglish"):
        return None  # No translation needed for display
    return f"[Translated from {lang}] {text}"


def run_pipeline(text: str) -> dict:
    """
    Full inference pipeline.
    Returns a dict compatible with complaint_service.create_complaint ai_data param.
    """
    # 1. Detect language
    lang_code, lang_name = detect_language(text)

    # 2. Clean text
    cleaned = clean_text(text)

    # 3. Extract keywords
    keywords = extract_keywords(cleaned)

    # 4. Try XLM-RoBERTa first, fall back to rules
    xlm_result = classify_with_xlm(cleaned)
    if xlm_result:
        category, confidence = xlm_result
        _, priority, _, rule_keywords = classify(cleaned)
        keywords = keywords or rule_keywords
    else:
        category, priority, confidence, rule_keywords = classify(cleaned)
        keywords = keywords or rule_keywords

    # 5. Department routing
    department = DEPT_MAP.get(category, "General Administration")

    # 6. Translation hint
    description_en = _simple_translate_hint(text, lang_code)

    return {
        "language":      lang_code,
        "language_name": lang_name,
        "description_en": description_en,
        "category":      category,
        "priority":      priority,
        "confidence":    confidence,
        "department":    department,
        "keywords":      keywords,
        "is_duplicate":  False,   # TODO: semantic similarity check
        "duplicate_of":  None,
        "sentiment":     None,    # TODO: sentiment analysis
    }
