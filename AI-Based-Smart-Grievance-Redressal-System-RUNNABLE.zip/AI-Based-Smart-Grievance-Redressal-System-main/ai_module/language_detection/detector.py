"""
Language Detection — Detects language of complaint text.
Handles English, Hindi, Hinglish, Marathi, Telugu, Tamil, Bengali.
"""

import re
from typing import Tuple

# Devanagari Unicode range
DEVANAGARI_RE = re.compile(r'[\u0900-\u097F]')
# Telugu
TELUGU_RE     = re.compile(r'[\u0C00-\u0C7F]')
# Tamil
TAMIL_RE      = re.compile(r'[\u0B80-\u0BFF]')
# Bengali
BENGALI_RE    = re.compile(r'[\u0980-\u09FF]')

# Common Hinglish / Romanized Hindi markers
HINGLISH_MARKERS = {
    "nahi", "nahin", "hai", "hain", "tha", "tha", "raha", "rahi", "kar",
    "karo", "kiya", "gaya", "aaya", "din", "mahine", "paani", "pani",
    "bijli", "sadak", "kaam", "nahi", "bhi", "aur", "se", "ka", "ki", "ke",
}

LANG_NAMES = {
    "en":      "English",
    "hi":      "Hindi",
    "hinglish":"Hinglish",
    "mr":      "Marathi",
    "te":      "Telugu",
    "ta":      "Tamil",
    "bn":      "Bengali",
    "unknown": "Unknown",
}


def detect_language(text: str) -> Tuple[str, str]:
    """
    Returns (lang_code, lang_name).
    Priority: script-based > Hinglish heuristic > langdetect fallback > 'en'.
    """
    if not text or not text.strip():
        return "en", "English"

    # Script-based detection (most reliable)
    dev_ratio  = len(DEVANAGARI_RE.findall(text)) / max(len(text), 1)
    tel_ratio  = len(TELUGU_RE.findall(text))    / max(len(text), 1)
    tam_ratio  = len(TAMIL_RE.findall(text))     / max(len(text), 1)
    ben_ratio  = len(BENGALI_RE.findall(text))   / max(len(text), 1)

    if dev_ratio > 0.1:
        # Could be Hindi or Marathi — use langdetect to distinguish
        try:
            from langdetect import detect
            code = detect(text)
            if code == "mr":
                return "mr", "Marathi"
            return "hi", "Hindi"
        except Exception:
            return "hi", "Hindi"

    if tel_ratio > 0.1:
        return "te", "Telugu"
    if tam_ratio > 0.1:
        return "ta", "Tamil"
    if ben_ratio > 0.1:
        return "bn", "Bengali"

    # Check Hinglish — Latin script but contains Hindi root words
    words = set(re.findall(r'\b\w+\b', text.lower()))
    hinglish_hits = words & HINGLISH_MARKERS
    if len(hinglish_hits) >= 2:
        return "hinglish", "Hinglish"

    # Fallback: langdetect
    try:
        from langdetect import detect, LangDetectException
        code = detect(text)
        name = LANG_NAMES.get(code, code.upper())
        return code, name
    except Exception:
        return "en", "English"


def get_display_name(lang_code: str) -> str:
    return LANG_NAMES.get(lang_code, lang_code.upper())
