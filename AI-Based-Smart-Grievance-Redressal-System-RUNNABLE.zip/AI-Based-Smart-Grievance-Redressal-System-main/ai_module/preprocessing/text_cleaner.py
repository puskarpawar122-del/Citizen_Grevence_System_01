"""
Text Preprocessing — Normalization for multilingual complaint text
"""

import re
import unicodedata


# Common abbreviations / noise to remove
NOISE_PATTERNS = [
    r'http\S+',          # URLs
    r'www\.\S+',
    r'\S+@\S+\.\S+',     # emails
    r'\d{10,}',          # phone numbers
]

# Hinglish/informal contractions → standard forms
HINGLISH_NORMALIZATIONS = {
    "nahi": "nahin",
    "paani": "paani",
    "bhi": "bhi",
    "karo": "karo",
    "aaya": "aaya",
    "ganda": "dirty",
    "kharab": "broken",
    "band": "closed",
}


def clean_text(text: str) -> str:
    """
    Full text cleaning pipeline:
    1. Unicode normalization
    2. Remove noise (URLs, emails, long numbers)
    3. Strip extra whitespace
    4. Preserve Devanagari and other Indian scripts
    """
    if not text:
        return ""

    # Normalize unicode (NFC — composed form)
    text = unicodedata.normalize("NFC", text)

    # Remove noise
    for pattern in NOISE_PATTERNS:
        text = re.sub(pattern, " ", text, flags=re.IGNORECASE)

    # Collapse whitespace
    text = re.sub(r'\s+', ' ', text).strip()

    return text


def normalize_hinglish(text: str) -> str:
    """Apply lightweight Hinglish normalization."""
    words = text.split()
    normalized = []
    for w in words:
        lower = w.lower()
        normalized.append(HINGLISH_NORMALIZATIONS.get(lower, w))
    return " ".join(normalized)


def extract_keywords(text: str, top_n: int = 8) -> list[str]:
    """
    Simple keyword extraction using word frequency
    (skip common stopwords).
    """
    STOP_WORDS = {
        "the", "a", "an", "is", "it", "in", "on", "at", "to", "for",
        "of", "and", "or", "but", "not", "are", "was", "has", "have",
        "this", "that", "with", "from", "we", "i", "my", "me", "our",
        "hai", "hain", "ka", "ki", "ke", "se", "bhi", "aur", "ne",
    }
    words = re.findall(r'\b[a-zA-Z\u0900-\u097F]{3,}\b', text.lower())
    freq: dict[str, int] = {}
    for w in words:
        if w not in STOP_WORDS:
            freq[w] = freq.get(w, 0) + 1
    sorted_words = sorted(freq.items(), key=lambda x: x[1], reverse=True)
    return [w for w, _ in sorted_words[:top_n]]
