"""
Classifier — Rule-based + optional XLM-RoBERTa classification.
Falls back gracefully if transformers library is unavailable.
"""

import re
from typing import Tuple

# ── Category taxonomy ──────────────────────────────────────────────────────

CATEGORIES = [
    "Water Supply",
    "Roads",
    "Electricity",
    "Sanitation",
    "Healthcare",
    "Education",
    "Public Safety",
    "Environment",
    "Transport",
    "Other",
]

DEPT_MAP = {
    "Water Supply":  "Municipal Water Supply Department",
    "Roads":         "Public Works Department (PWD)",
    "Electricity":   "State Electricity Board",
    "Sanitation":    "Sanitation & Waste Management Dept.",
    "Healthcare":    "District Health Office",
    "Education":     "District Education Officer",
    "Public Safety": "Local Police / Safety Department",
    "Environment":   "Environment & Pollution Control Board",
    "Transport":     "Regional Transport Office (RTO)",
    "Other":         "General Administration",
}

# ── Multilingual keyword rules ─────────────────────────────────────────────
# Each rule: (keyword_list, category, base_priority)

RULES: list[tuple[list[str], str, str]] = [
    (
        ["water", "paani", "pani", "पानी", "पाणी", "nal", "pipe",
         "leak", "supply", "nali", "jal", "waterline", "nala"],
        "Water Supply", "HIGH"
    ),
    (
        ["road", "pothole", "sadak", "सड़क", "रास्ता", "street", "highway",
         "footpath", "crack", "tar", "pavement", "broken road"],
        "Roads", "MEDIUM"
    ),
    (
        ["electricity", "light", "current", "bijli", "बिजली", "power",
         "outage", "wire", "transformer", "blackout", "voltage", "shock"],
        "Electricity", "HIGH"
    ),
    (
        ["garbage", "waste", "kachara", "कचरा", "drain", "sewage",
         "smell", "stink", "gutter", "kuda", "toilet", "sanitation"],
        "Sanitation", "HIGH"
    ),
    (
        ["hospital", "doctor", "medicine", "health", "ambulance",
         "clinic", "स्वास्थ्य", "dawai", "swasthya", "nurse", "treatment"],
        "Healthcare", "CRITICAL"
    ),
    (
        ["school", "teacher", "education", "शिक्षा", "student",
         "fees", "scholarship", "books", "vidyalaya", "college"],
        "Education", "MEDIUM"
    ),
    (
        ["police", "crime", "theft", "robbery", "safety", "security",
         "chori", "चोरी", "danger", "attack", "harassment", "eve"],
        "Public Safety", "CRITICAL"
    ),
    (
        ["tree", "pollution", "smoke", "environment", "प्रदूषण",
         "factory", "chemical", "noise", "dust", "air quality"],
        "Environment", "MEDIUM"
    ),
    (
        ["bus", "auto", "transport", "vehicle", "traffic",
         "parking", "परिवहन", "route", "ferry", "rickshaw"],
        "Transport", "LOW"
    ),
]

CRITICAL_SIGNALS = [
    "emergency", "urgent", "immediately", "death", "fire", "flood",
    "danger", "critical", "dead", "collapsed", "explosion", "life",
    "3 din", "7 din", "week", "month", "mahine", "hafte",
]

HIGH_SIGNALS = ["not working", "broken", "damaged", "no supply", "please help"]


def classify(text: str) -> Tuple[str, str, float, list[str]]:
    """
    Returns (category, priority, confidence, keywords).
    """
    lower = text.lower()
    best_category = "Other"
    best_priority = "MEDIUM"
    best_confidence = 0.50
    best_keywords: list[str] = []

    for kw_list, category, priority in RULES:
        hits = [kw for kw in kw_list if kw in lower]
        if hits:
            confidence = min(0.97, 0.60 + 0.05 * len(hits))
            if confidence > best_confidence:
                best_category   = category
                best_priority   = priority
                best_confidence = confidence
                best_keywords   = hits

    # Priority escalation
    for signal in CRITICAL_SIGNALS:
        if signal in lower:
            best_priority = "CRITICAL"
            break

    if best_priority != "CRITICAL":
        for signal in HIGH_SIGNALS:
            if signal in lower:
                if best_priority in ("LOW", "MEDIUM"):
                    best_priority = "HIGH"

    return best_category, best_priority, round(best_confidence, 2), best_keywords


# ── Optional XLM-RoBERTa model ─────────────────────────────────────────────

_xlm_pipeline = None


def _load_xlm_model():
    """Lazy-load the XLM-RoBERTa model if transformers is available."""
    global _xlm_pipeline
    if _xlm_pipeline is not None:
        return _xlm_pipeline
    try:
        from transformers import pipeline as hf_pipeline
        _xlm_pipeline = hf_pipeline(
            "zero-shot-classification",
            model="joeddav/xlm-roberta-large-xnli",
        )
        return _xlm_pipeline
    except Exception:
        return None


def classify_with_xlm(text: str) -> Tuple[str, float] | None:
    """
    Use zero-shot XLM-RoBERTa if available.
    Returns (category, confidence) or None if unavailable.
    """
    pipe = _load_xlm_model()
    if not pipe:
        return None
    try:
        result = pipe(text, CATEGORIES, multi_label=False)
        return result["labels"][0], round(result["scores"][0], 2)
    except Exception:
        return None
