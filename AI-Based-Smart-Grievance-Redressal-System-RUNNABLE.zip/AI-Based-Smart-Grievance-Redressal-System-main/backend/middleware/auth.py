"""
Middleware — JWT Authentication & Authorization
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt
import os
from datetime import datetime, timedelta

SECRET_KEY  = os.getenv("JWT_SECRET", "nyayavaani-dev-secret-change-in-prod")
ALGORITHM   = "HS256"
TOKEN_EXPIRE_HOURS = 24

bearer_scheme = HTTPBearer(auto_error=False)


def create_jwt(payload: dict, hours: int = TOKEN_EXPIRE_HOURS) -> str:
    """Create a signed JWT for admin sessions."""
    data = payload.copy()
    data["exp"] = datetime.utcnow() + timedelta(hours=hours)
    return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)


def decode_jwt(token: str) -> dict:
    """Decode and verify a JWT. Raises HTTPException on failure."""
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


def get_current_admin(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
) -> dict:
    """Dependency — verifies admin JWT and returns payload."""
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return decode_jwt(credentials.credentials)


def get_current_citizen_token(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
) -> str:
    """
    Dependency — verifies a citizen JWT (issued after token-login)
    and returns the citizen token string.
    """
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")
    payload = decode_jwt(credentials.credentials)
    citizen_token = payload.get("citizen_token")
    if not citizen_token:
        raise HTTPException(status_code=403, detail="Not a citizen token")
    return citizen_token
