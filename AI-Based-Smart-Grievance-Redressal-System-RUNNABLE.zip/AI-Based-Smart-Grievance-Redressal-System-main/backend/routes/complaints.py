"""
Complaint Routes — /api/complaints/*
Updated: multi-photo (4), multi-video (2), per-photo GPS, approve/deny endpoints.
"""

import os
import shutil
import logging
import threading
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import get_db
from middleware.auth import get_current_citizen_token, get_current_admin
from services.complaint_service import (
    create_complaint,
    get_complaint_by_cid,
    get_complaints_by_token,
    get_all_complaints,
    get_kpi_stats,
    update_complaint_status,
    save_ai_feedback,
)
from services.ai_service import analyze_complaint

logger = logging.getLogger(__name__)
router = APIRouter()

# ── AI Warmup on startup (runs in background thread so server starts instantly) ──
def _warmup_ai():
    """Pre-load the AI model so the first complaint doesn't hang."""
    try:
        logger.info("[AI Warmup] Loading AI model in background...")
        analyze_complaint("test warmup road pothole")
        logger.info("[AI Warmup] AI model ready.")
    except Exception as e:
        logger.warning(f"[AI Warmup] Failed (rule-based fallback will be used): {e}")

threading.Thread(target=_warmup_ai, daemon=True).start()

UPLOAD_DIR       = "uploads"
VIDEO_UPLOAD_DIR = os.path.join("uploads", "videos")
MAX_VIDEO_BYTES  = 50 * 1024 * 1024  # 50 MB


# ── Helper: save uploaded file ─────────────────────────────────────────────

def _save_file(upload: UploadFile, directory: str, prefix: str, allowed_exts: tuple) -> Optional[str]:
    if not upload or not upload.filename:
        return None
    ext = os.path.splitext(upload.filename)[1].lower()
    if ext not in allowed_exts:
        raise HTTPException(status_code=400, detail=f"Invalid file type: {ext}")
    os.makedirs(directory, exist_ok=True)
    fname = f"{prefix}_{os.urandom(4).hex()}{ext}"
    path  = os.path.join(directory, fname)
    upload.file.seek(0, 2)         # seek to end
    size = upload.file.tell()
    upload.file.seek(0)            # reset
    if directory == VIDEO_UPLOAD_DIR and size > MAX_VIDEO_BYTES:
        raise HTTPException(status_code=400, detail="Video exceeds 50 MB limit")
    with open(path, "wb") as f:
        shutil.copyfileobj(upload.file, f)
    return path


# ── Helper: serialize complaint ────────────────────────────────────────────

def _serialize(c) -> dict:
    def _img_url(path):
        return f"/uploads/{os.path.basename(path)}" if path else None
    def _vid_url(path):
        return f"/uploads/videos/{os.path.basename(path)}" if path else None

    photos = []
    for i, (ip, lat, lng) in enumerate([
        (c.image_path,   c.photo_lat_1, c.photo_lng_1),
        (c.image_path_2, c.photo_lat_2, c.photo_lng_2),
        (c.image_path_3, c.photo_lat_3, c.photo_lng_3),
        (c.image_path_4, c.photo_lat_4, c.photo_lng_4),
    ], 1):
        if ip:
            photos.append({
                "url":  _img_url(ip),
                "lat":  lat,
                "lng":  lng,
                "index": i,
            })

    videos = []
    for vp in [c.video_path, c.video_path_2]:
        if vp:
            videos.append({"url": _vid_url(vp)})

    return {
        "id":              c.complaint_id,
        "description":     c.description,
        "description_en":  c.description_en,
        "language":        c.detected_lang,
        "category":        c.category,
        "priority":        c.priority,
        "confidence":      c.ai_confidence,
        "is_duplicate":    c.is_duplicate,
        "status":          c.status,
        "denial_reason":   c.denial_reason,
        "department":      c.routed_dept,
        "latitude":        c.latitude,
        "longitude":       c.longitude,
        "locality":        c.locality,
        # Legacy single image_url kept for backward compat
        "image_url":       _img_url(c.image_path),
        "photos":          photos,
        "videos":          videos,
        "escalated":       c.escalated,
        "created_at":      c.created_at.isoformat() if c.created_at else None,
        "updated_at":      c.updated_at.isoformat() if c.updated_at else None,
        "history": [
            {
                "status":     h.status,
                "note":       h.note,
                "changed_by": h.changed_by,
                "changed_at": h.changed_at.isoformat() if h.changed_at else None,
            }
            for h in (c.history or [])
        ],
    }


# ── Citizen Endpoints ──────────────────────────────────────────────────────

IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".webp")
VIDEO_EXTS = (".mp4", ".mov", ".webm", ".avi")

@router.post("/submit", summary="Submit a new complaint (citizen)")
def submit_complaint(
    description: str            = Form(...),
    latitude:    Optional[float] = Form(None),
    longitude:   Optional[float] = Form(None),
    locality:    Optional[str]   = Form(None),
    # Up to 4 photos
    image_1:     Optional[UploadFile] = File(None),
    image_2:     Optional[UploadFile] = File(None),
    image_3:     Optional[UploadFile] = File(None),
    image_4:     Optional[UploadFile] = File(None),
    # Per-photo GPS proof
    photo_lat_1: Optional[float] = Form(None),
    photo_lng_1: Optional[float] = Form(None),
    photo_lat_2: Optional[float] = Form(None),
    photo_lng_2: Optional[float] = Form(None),
    photo_lat_3: Optional[float] = Form(None),
    photo_lng_3: Optional[float] = Form(None),
    photo_lat_4: Optional[float] = Form(None),
    photo_lng_4: Optional[float] = Form(None),
    # Up to 2 videos
    video_1:     Optional[UploadFile] = File(None),
    video_2:     Optional[UploadFile] = File(None),
    citizen_token: str = Depends(get_current_citizen_token),
    db: Session = Depends(get_db),
):
    prefix = citizen_token[:8]
    logger.info(f"[Submit] Citizen {prefix} submitting complaint...")

    try:
        img_path_1 = _save_file(image_1, UPLOAD_DIR,       f"{prefix}_p1", IMAGE_EXTS)
        img_path_2 = _save_file(image_2, UPLOAD_DIR,       f"{prefix}_p2", IMAGE_EXTS)
        img_path_3 = _save_file(image_3, UPLOAD_DIR,       f"{prefix}_p3", IMAGE_EXTS)
        img_path_4 = _save_file(image_4, UPLOAD_DIR,       f"{prefix}_p4", IMAGE_EXTS)
        vid_path_1 = _save_file(video_1, VIDEO_UPLOAD_DIR, f"{prefix}_v1", VIDEO_EXTS)
        vid_path_2 = _save_file(video_2, VIDEO_UPLOAD_DIR, f"{prefix}_v2", VIDEO_EXTS)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[Submit] File save error: {e}")
        raise HTTPException(status_code=500, detail=f"File upload failed: {str(e)}")

    # AI analysis — fallback to rule-based if model is still loading
    try:
        logger.info(f"[Submit] Running AI analysis...")
        ai_data = analyze_complaint(description)
        logger.info(f"[Submit] AI done: category={ai_data.get('category')}, priority={ai_data.get('priority')}")
    except Exception as e:
        logger.warning(f"[Submit] AI analysis failed, using defaults: {e}")
        ai_data = {
            "language": "en", "description_en": None,
            "category": "Other", "priority": "MEDIUM",
            "confidence": 0.5, "is_duplicate": False, "duplicate_of": None,
            "department": "General Administration", "keywords": [], "sentiment": None,
        }

    try:
        complaint = create_complaint(
            db           = db,
            token_id     = citizen_token,
            description  = description,
            ai_data      = ai_data,
            latitude     = latitude,
            longitude    = longitude,
            locality     = locality,
            image_path   = img_path_1,
        )

        # Set extra photo/video fields directly
        if img_path_2:    complaint.image_path_2 = img_path_2
        if img_path_3:    complaint.image_path_3 = img_path_3
        if img_path_4:    complaint.image_path_4 = img_path_4
        if photo_lat_1:   complaint.photo_lat_1  = photo_lat_1
        if photo_lng_1:   complaint.photo_lng_1  = photo_lng_1
        if photo_lat_2:   complaint.photo_lat_2  = photo_lat_2
        if photo_lng_2:   complaint.photo_lng_2  = photo_lng_2
        if photo_lat_3:   complaint.photo_lat_3  = photo_lat_3
        if photo_lng_3:   complaint.photo_lng_3  = photo_lng_3
        if photo_lat_4:   complaint.photo_lat_4  = photo_lat_4
        if photo_lng_4:   complaint.photo_lng_4  = photo_lng_4
        if vid_path_1:    complaint.video_path   = vid_path_1
        if vid_path_2:    complaint.video_path_2 = vid_path_2
        db.commit()
        db.refresh(complaint)
        logger.info(f"[Submit] Complaint saved: {complaint.complaint_id}")

    except Exception as e:
        logger.error(f"[Submit] DB save error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to save complaint: {str(e)}")

    return {"success": True, "complaint": _serialize(complaint)}


@router.get("/mine", summary="Get all complaints for the logged-in citizen")
def my_complaints(
    status: Optional[str] = None,
    skip:   int = 0,
    limit:  int = 50,
    citizen_token: str = Depends(get_current_citizen_token),
    db: Session = Depends(get_db),
):
    complaints = get_complaints_by_token(db, citizen_token, status, skip, limit)
    return {"complaints": [_serialize(c) for c in complaints]}


@router.get("/track/{complaint_id}", summary="Track a complaint by its public ID")
def track_complaint(complaint_id: str, db: Session = Depends(get_db)):
    c = get_complaint_by_cid(db, complaint_id)
    if not c:
        raise HTTPException(status_code=404, detail="Complaint not found")
    return _serialize(c)


# ── Admin Endpoints ────────────────────────────────────────────────────────

@router.get("/admin/all", summary="Admin — list all complaints")
def admin_list(
    status:   Optional[str] = None,
    category: Optional[str] = None,
    priority: Optional[str] = None,
    skip:     int = 0,
    limit:    int = 100,
    admin = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    complaints = get_all_complaints(db, status, category, priority, skip, limit)
    return {"complaints": [_serialize(c) for c in complaints]}


@router.get("/admin/kpi", summary="Admin — KPI stats")
def admin_kpi(admin = Depends(get_current_admin), db: Session = Depends(get_db)):
    return get_kpi_stats(db)


class StatusUpdateRequest(BaseModel):
    status: str
    note:   Optional[str] = None

@router.patch("/admin/{complaint_id}/status", summary="Admin — update complaint status")
def admin_update_status(
    complaint_id: str,
    body: StatusUpdateRequest,
    admin = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    valid_statuses = {"pending", "in_progress", "resolved", "escalated", "denied"}
    if body.status not in valid_statuses:
        raise HTTPException(status_code=400, detail=f"Invalid status. Choose from {valid_statuses}")
    c = update_complaint_status(db, complaint_id, body.status, admin["sub"], body.note)
    if not c:
        raise HTTPException(status_code=404, detail="Complaint not found")
    return {"success": True, "complaint": _serialize(c)}


@router.post("/admin/{complaint_id}/approve", summary="Admin — approve a complaint")
def admin_approve(
    complaint_id: str,
    admin = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    """Mark complaint as approved (moves to in_progress) and logs the action."""
    c = get_complaint_by_cid(db, complaint_id)
    if not c:
        raise HTTPException(status_code=404, detail="Complaint not found")
    c = update_complaint_status(db, complaint_id, "in_progress", admin["sub"], "Complaint approved by supervisor.")
    return {"success": True, "complaint": _serialize(c)}


class DenyRequest(BaseModel):
    reason: str

@router.post("/admin/{complaint_id}/deny", summary="Admin — deny a complaint with reason")
def admin_deny(
    complaint_id: str,
    body: DenyRequest,
    admin = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    """Deny a complaint — stores the denial reason visible to the citizen."""
    if not body.reason or len(body.reason.strip()) < 5:
        raise HTTPException(status_code=400, detail="Please provide a meaningful denial reason.")
    c = get_complaint_by_cid(db, complaint_id)
    if not c:
        raise HTTPException(status_code=404, detail="Complaint not found")
    c.denial_reason = body.reason.strip()
    db.commit()
    c = update_complaint_status(db, complaint_id, "denied", admin["sub"], f"Denied: {body.reason.strip()}")
    return {"success": True, "complaint": _serialize(c)}
