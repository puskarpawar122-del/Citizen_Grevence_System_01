"""
Notice Routes — /api/notices/*
Supervisor broadcast notices to citizens (ward/zone targeted).
"""

import os
import shutil
from typing import Optional
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import get_db
from middleware.auth import get_current_admin
from models.notice import Notice

router = APIRouter()

NOTICE_PHOTO_DIR = os.path.join("uploads", "notices")


# ── Helpers ────────────────────────────────────────────────────────────────

def _serialize_notice(n: Notice) -> dict:
    return {
        "id":         n.id,
        "title":      n.title,
        "message":    n.message,
        "severity":   n.severity,
        "ward_tag":   n.ward_tag,
        "zone_tag":   n.zone_tag,
        "photo_url":  f"/uploads/notices/{os.path.basename(n.photo_path)}" if n.photo_path else None,
        "video_url":  f"/uploads/notices/{os.path.basename(n.video_path)}" if n.video_path else None,
        "created_by": n.created_by,
        "is_active":  n.is_active,
        "expires_at": n.expires_at.isoformat() if n.expires_at else None,
        "created_at": n.created_at.isoformat() if n.created_at else None,
    }


# ── Public Endpoints (Citizens) ───────────────────────────────────────────

@router.get("/", summary="List active notices (citizen view)")
def list_notices(
    ward:  Optional[str] = None,
    zone:  Optional[str] = None,
    db: Session = Depends(get_db),
):
    """
    Returns all active, non-expired notices.
    Optionally filter by ward or zone to show area-relevant notices first.
    """
    now = datetime.utcnow()
    q = db.query(Notice).filter(
        Notice.is_active == True,
    )
    # Include notices that are: (a) untargeted OR (b) match the citizen's ward/zone
    notices = q.order_by(Notice.created_at.desc()).all()

    # For prototype, show all active notices without filtering by ward/zone
    result = [n for n in notices if n.is_active and (n.expires_at is None or n.expires_at > now)]
    return {"notices": [_serialize_notice(n) for n in result]}


# ── Admin Endpoints ────────────────────────────────────────────────────────

@router.get("/admin/all", summary="Admin — list all notices including inactive")
def admin_list_notices(
    admin = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    notices = db.query(Notice).order_by(Notice.created_at.desc()).all()
    return {"notices": [_serialize_notice(n) for n in notices]}


@router.post("/admin/create", summary="Admin — create and broadcast a notice")
async def create_notice(
    title:     str                   = Form(...),
    message:   str                   = Form(...),
    severity:  str                   = Form("info"),
    ward_tag:  Optional[str]         = Form(None),
    zone_tag:  Optional[str]         = Form(None),
    expires_in_hours: Optional[int]  = Form(None),
    photo:     Optional[UploadFile]  = File(None),
    video:     Optional[UploadFile]  = File(None),
    admin = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    if severity not in ("info", "warning", "critical"):
        raise HTTPException(status_code=400, detail="severity must be info | warning | critical")

    # Save optional supervisor photo
    photo_path = None
    if photo and photo.filename:
        ext = os.path.splitext(photo.filename)[1].lower()
        if ext not in (".jpg", ".jpeg", ".png", ".webp"):
            raise HTTPException(status_code=400, detail="Invalid photo format")
        os.makedirs(NOTICE_PHOTO_DIR, exist_ok=True)
        fname = f"notice_{os.urandom(6).hex()}{ext}"
        photo_path = os.path.join(NOTICE_PHOTO_DIR, fname)
        with open(photo_path, "wb") as f:
            shutil.copyfileobj(photo.file, f)

    video_path = None
    if video and video.filename:
        ext = os.path.splitext(video.filename)[1].lower()
        if ext not in (".mp4", ".mov", ".webm", ".avi"):
            raise HTTPException(status_code=400, detail="Invalid video format")
        os.makedirs(NOTICE_PHOTO_DIR, exist_ok=True)
        fname = f"notice_vid_{os.urandom(6).hex()}{ext}"
        video_path = os.path.join(NOTICE_PHOTO_DIR, fname)
        with open(video_path, "wb") as f:
            shutil.copyfileobj(video.file, f)

    expires_at = None
    if expires_in_hours:
        expires_at = datetime.utcnow() + __import__("datetime").timedelta(hours=expires_in_hours)

    notice = Notice(
        title      = title,
        message    = message,
        severity   = severity,
        ward_tag   = ward_tag,
        zone_tag   = zone_tag,
        photo_path = photo_path,
        video_path = video_path,
        expires_at = expires_at,
        created_by = admin["sub"],
    )
    db.add(notice)
    db.commit()
    db.refresh(notice)
    return {"success": True, "notice": _serialize_notice(notice)}


@router.patch("/admin/{notice_id}/deactivate", summary="Admin — deactivate/archive a notice")
def deactivate_notice(
    notice_id: str,
    admin = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    n = db.query(Notice).filter(Notice.id == notice_id).first()
    if not n:
        raise HTTPException(status_code=404, detail="Notice not found")
    n.is_active = False
    db.commit()
    return {"success": True}
