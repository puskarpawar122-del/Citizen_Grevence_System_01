"""
AI Routes — /api/ai/*
Real-time analysis endpoint + feedback loop endpoint
"""

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import Optional
from sqlalchemy.orm import Session

from database import get_db
from middleware.auth import get_current_admin
from services.ai_service import analyze_complaint, get_ai_stats
from services.complaint_service import save_ai_feedback

router = APIRouter()


class AnalyzeRequest(BaseModel):
    text: str
    language: Optional[str] = "auto"


class FeedbackRequest(BaseModel):
    complaint_id:       str
    corrected_category: Optional[str] = None
    corrected_priority: Optional[str] = None
    flag_reason:        Optional[str] = None


@router.post("/analyze", summary="Real-time AI analysis of complaint text")
def analyze(body: AnalyzeRequest):
    """
    Called on-the-fly from the frontend as the user types.
    Returns detected language, category, priority, department.
    """
    result = analyze_complaint(body.text, body.language or "auto")
    return result


@router.post("/feedback", summary="Admin — submit AI correction feedback")
def submit_feedback(
    body: FeedbackRequest,
    admin = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    ok = save_ai_feedback(
        db,
        body.complaint_id,
        body.corrected_category,
        body.corrected_priority,
        body.flag_reason,
    )
    if not ok:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Complaint or AI result not found")
    return {"success": True, "message": "Feedback recorded. Will be used in next training cycle."}


@router.get("/stats", summary="Admin — AI model accuracy stats")
def ai_stats(admin = Depends(get_current_admin), db: Session = Depends(get_db)):
    return get_ai_stats(db)


@router.get("/analytics", summary="Admin — complaint analytics data for charts")
def analytics(admin = Depends(get_current_admin), db: Session = Depends(get_db)):
    """Returns aggregated data for all 5 admin analytics charts."""
    from models.complaint import Complaint
    from sqlalchemy import func

    # Category distribution
    cat_data = db.query(Complaint.category, func.count(Complaint.id)).group_by(Complaint.category).all()
    # Priority distribution
    pri_data = db.query(Complaint.priority, func.count(Complaint.id)).group_by(Complaint.priority).all()
    # Language distribution
    lang_data = db.query(Complaint.detected_lang, func.count(Complaint.id)).group_by(Complaint.detected_lang).all()
    # Department resolution
    dept_data = db.query(
        Complaint.routed_dept,
        func.count(Complaint.id),
        func.sum(func.case((Complaint.status == "resolved", 1), else_=0))
    ).group_by(Complaint.routed_dept).all()
    # Timeline (last 7 weeks, simplified)
    timeline_data = db.query(
        func.strftime("%W", Complaint.created_at).label("week"),
        func.count(Complaint.id)
    ).group_by("week").order_by("week").limit(7).all()

    return {
        "category":  [{"label": r[0] or "Unknown", "count": r[1]} for r in cat_data],
        "priority":  [{"label": r[0], "count": r[1]} for r in pri_data],
        "language":  [{"label": r[0], "count": r[1]} for r in lang_data],
        "department":[{"dept": r[0] or "Unknown", "total": r[1], "resolved": int(r[2] or 0)} for r in dept_data],
        "timeline":  [{"week": f"Week {r[0]}", "count": r[1]} for r in timeline_data],
    }
