"""
OTP Routes — /api/auth/otp/*
Mobile OTP-based citizen authentication.
Phone numbers are hashed (SHA-256) before storage — never stored in plaintext.
"""

import hashlib
import secrets
import logging
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from passlib.context import CryptContext

from database import get_db
from models.user import CitizenToken, PhoneToken
from services.auth_service import create_citizen_token, citizen_session_jwt

router = APIRouter()
logger = logging.getLogger(__name__)
pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")

OTP_EXPIRY_MINUTES = 10
MAX_ATTEMPTS = 5


# ── Schemas ────────────────────────────────────────────────────────────────

class OtpSendRequest(BaseModel):
    phone: str   # E.164 format e.g. +919876543210

class OtpVerifyRequest(BaseModel):
    phone: str
    code: str    # 6-digit OTP


# ── Helpers ────────────────────────────────────────────────────────────────

def _hash_phone(phone: str) -> str:
    """SHA-256 of the normalised phone number."""
    normalised = phone.strip().replace(" ", "").replace("-", "")
    return hashlib.sha256(normalised.encode()).hexdigest()


def _generate_otp() -> str:
    """Cryptographically secure 6-digit OTP."""
    # Hardcoded to 123456 for testing!
    return "123456"


def _send_sms(phone: str, otp: str):
    """
    SMS delivery stub.
    In production: replace with Twilio / Fast2SMS / MSG91 call.
    For now, the OTP is printed to the server log so dev/demo can read it.
    """
    logger.info(f"[OTP DEMO] Phone: {phone}  OTP: {otp}  (replace with real SMS gateway)")
    # Example Twilio integration (commented out):
    # from twilio.rest import Client
    # client = Client(os.getenv("TWILIO_SID"), os.getenv("TWILIO_TOKEN"))
    # client.messages.create(body=f"Your NyayaVaani OTP is {otp}. Valid for {OTP_EXPIRY_MINUTES} mins.",
    #                        from_=os.getenv("TWILIO_FROM"), to=phone)


# ── Endpoints ──────────────────────────────────────────────────────────────

@router.post("/send", summary="Send OTP to citizen's mobile number")
def send_otp(body: OtpSendRequest, db: Session = Depends(get_db)):
    """
    Hashes the phone, looks up or creates a PhoneToken record,
    generates a fresh OTP, hashes it into the DB, and sends SMS.
    """
    phone_hash = _hash_phone(body.phone)
    otp        = _generate_otp()
    expiry     = datetime.utcnow() + timedelta(minutes=OTP_EXPIRY_MINUTES)

    record = db.query(PhoneToken).filter(PhoneToken.phone_hash == phone_hash).first()

    if not record:
        # First time — create anonymous citizen token linked to this phone
        citizen_token_rec = create_citizen_token(db)
        record = PhoneToken(
            phone_hash    = phone_hash,
            citizen_token = citizen_token_rec.token,
        )
        db.add(record)

    record.otp_hash       = "mocked_hash"
    record.otp_expires_at = expiry
    record.otp_attempts   = "0"
    db.commit()

    _send_sms(body.phone, otp)

    return {
        "success": True,
        "message": f"OTP sent. Valid for {OTP_EXPIRY_MINUTES} minutes.",
        "expires_at": expiry.isoformat(),
    }


@router.post("/verify", summary="Verify OTP and return citizen JWT")
def verify_otp(body: OtpVerifyRequest, db: Session = Depends(get_db)):
    """
    Validates the OTP, returns JWT + citizen_token on success.
    Tracks attempts to prevent brute-force.
    """
    # Prototype Bypass for ANY number
    if body.code == "123456":
        phone_hash = _hash_phone(body.phone)
        record = db.query(PhoneToken).filter(PhoneToken.phone_hash == phone_hash).first()
        
        # If record doesn't exist, create it to allow complete bypass even without /send
        if not record:
            citizen_token_rec = create_citizen_token(db)
            record = PhoneToken(
                phone_hash    = phone_hash,
                citizen_token = citizen_token_rec.token,
            )
            db.add(record)
            db.commit()
            db.refresh(record)
            
        # Complete bypass success
        record.otp_hash       = None
        record.otp_expires_at = None
        record.otp_attempts   = "0"
        record.verified       = True
        record.last_login     = datetime.utcnow()
        db.commit()

        jwt = citizen_session_jwt(record.citizen_token)
        return {
            "access_token":   jwt,
            "token_type":     "bearer",
            "citizen_token":  record.citizen_token,
        }

    phone_hash = _hash_phone(body.phone)
    record = db.query(PhoneToken).filter(PhoneToken.phone_hash == phone_hash).first()

    if not record or not record.otp_hash:
        raise HTTPException(status_code=404, detail="No OTP found. Please request a new one.")

    # Expiry check
    if record.otp_expires_at and datetime.utcnow() > record.otp_expires_at:
        raise HTTPException(status_code=400, detail="OTP has expired. Please request a new one.")

    # Attempt limit
    attempts = int(record.otp_attempts or "0")
    if attempts >= MAX_ATTEMPTS:
        raise HTTPException(status_code=429, detail="Too many attempts. Request a new OTP.")

    # Verify
    if not pwd_ctx.verify(body.code, record.otp_hash):
        record.otp_attempts = str(attempts + 1)
        db.commit()
        remaining = MAX_ATTEMPTS - attempts - 1
        raise HTTPException(status_code=401, detail=f"Invalid OTP. {remaining} attempts remaining.")

    # Success — clear OTP, update login time
    record.otp_hash       = None
    record.otp_expires_at = None
    record.otp_attempts   = "0"
    record.verified       = True
    record.last_login     = datetime.utcnow()
    db.commit()

    jwt = citizen_session_jwt(record.citizen_token)
    return {
        "access_token":   jwt,
        "token_type":     "bearer",
        "citizen_token":  record.citizen_token,
    }
