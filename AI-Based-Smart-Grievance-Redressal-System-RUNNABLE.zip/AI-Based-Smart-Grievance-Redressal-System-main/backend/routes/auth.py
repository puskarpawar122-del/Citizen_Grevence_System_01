"""
Auth Routes — /api/auth/*
"""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import get_db
from services.auth_service import (
    create_citizen_token,
    verify_citizen_token,
    citizen_session_jwt,
    authenticate_admin,
    admin_session_jwt,
    seed_default_admin,
)

router = APIRouter()


# ── Schemas ────────────────────────────────────────────────────────────────

class TokenLoginRequest(BaseModel):
    token: str

class AdminLoginRequest(BaseModel):
    username: str
    password: str


# ── Endpoints ──────────────────────────────────────────────────────────────

@router.post("/token/generate", summary="Generate anonymous citizen token")
def generate_token(db: Session = Depends(get_db)):
    """Issues a new anonymous token. No personal data required."""
    record = create_citizen_token(db)
    return {"token": record.token, "created_at": record.created_at}


@router.post("/token/login", summary="Citizen login with token")
def token_login(body: TokenLoginRequest, db: Session = Depends(get_db)):
    record = verify_citizen_token(body.token, db)
    if not record:
        raise HTTPException(status_code=401, detail="Invalid or inactive token")
    jwt_token = citizen_session_jwt(record.token)
    return {"access_token": jwt_token, "token_type": "bearer", "citizen_token": record.token}


@router.post("/admin/login", summary="Admin login with credentials")
def admin_login(body: AdminLoginRequest, db: Session = Depends(get_db)):
    # Ensure default admin exists
    seed_default_admin(db)
    admin = authenticate_admin(body.username, body.password, db)
    if not admin:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    jwt_token = admin_session_jwt(admin)
    return {
        "access_token": jwt_token,
        "token_type": "bearer",
        "admin": {
            "username": admin.username,
            "full_name": admin.full_name,
            "department": admin.department,
            "is_superadmin": admin.is_superadmin,
        },
    }
