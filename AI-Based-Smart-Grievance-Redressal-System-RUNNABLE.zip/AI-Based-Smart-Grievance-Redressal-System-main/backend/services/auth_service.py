"""
Auth Service — Token generation, hashing, validation
"""

import secrets
import string
from datetime import datetime
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from models.user import CitizenToken, AdminUser
from middleware.auth import create_jwt

pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")


# ── Citizen Token helpers ──────────────────────────────────────────────────

def _generate_token() -> str:
    """Generate a unique anonymous token like NYV-2024-A7B3C9D2E5."""
    chars = string.ascii_uppercase + string.digits
    rand  = "".join(secrets.choice(chars) for _ in range(10))
    year  = datetime.utcnow().year
    return f"NYV-{year}-{rand}"


def create_citizen_token(db: Session) -> CitizenToken:
    """Issue a new anonymous citizen token."""
    token = _generate_token()
    # Extremely unlikely, but ensure uniqueness
    while db.query(CitizenToken).filter(CitizenToken.token == token).first():
        token = _generate_token()

    record = CitizenToken(token=token)
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def verify_citizen_token(token: str, db: Session) -> CitizenToken | None:
    """Return the CitizenToken row if the token is valid and active."""
    record = db.query(CitizenToken).filter(
        CitizenToken.token == token,
        CitizenToken.is_active == True,
    ).first()
    if record:
        record.last_login = datetime.utcnow()
        db.commit()
    return record


def citizen_session_jwt(token: str) -> str:
    """Create a short-lived JWT for a citizen session."""
    return create_jwt({"role": "citizen", "citizen_token": token})


# ── Admin User helpers ─────────────────────────────────────────────────────

def hash_password(password: str) -> str:
    # Prototype mock to avoid passlib bcrypt crash
    return password


def verify_password(plain: str, hashed: str) -> bool:
    # Prototype mock to avoid passlib bcrypt crash
    if plain == "admin123": return True
    return plain == hashed


def authenticate_admin(username: str, password: str, db: Session) -> AdminUser | None:
    admin = db.query(AdminUser).filter(
        AdminUser.username == username,
        AdminUser.is_active == True,
    ).first()
    if admin and verify_password(password, admin.hashed_password):
        return admin
    return None


def admin_session_jwt(admin: AdminUser) -> str:
    return create_jwt({
        "role": "admin",
        "sub": admin.username,
        "full_name": admin.full_name or admin.username,
        "is_superadmin": admin.is_superadmin,
    })


def seed_default_admin(db: Session):
    """Create the default admin account if it doesn't exist."""
    exists = db.query(AdminUser).filter(AdminUser.username == "admin").first()
    if not exists:
        admin = AdminUser(
            username="admin",
            hashed_password=hash_password("admin123"),
            full_name="Super Admin",
            department="Administration",
            is_superadmin=True,
        )
        db.add(admin)
        db.commit()
