"""
Complaint Service — CRUD, filtering, pagination, status updates
"""

import os
import uuid
from datetime import datetime
from typing import Optional
from sqlalchemy.orm import Session
from sqlalchemy import func

from models.complaint import Complaint, StatusHistory, AIResult


# ── ID generation ──────────────────────────────────────────────────────────

def _generate_complaint_id(db: Session) -> str:
    year   = datetime.utcnow().year
    count  = db.query(func.count(Complaint.id)).scalar() + 1
    return f"CMP-{year}-{count:05d}"


# ── Create ─────────────────────────────────────────────────────────────────

def create_complaint(
    db: Session,
    token_id: str,
    description: str,
    ai_data: dict,
    latitude: Optional[float] = None,
    longitude: Optional[float] = None,
    locality: Optional[str] = None,
    image_path: Optional[str] = None,
) -> Complaint:
    complaint = Complaint(
        complaint_id    = _generate_complaint_id(db),
        token_id        = token_id,
        description     = description,
        description_en  = ai_data.get("description_en"),
        detected_lang   = ai_data.get("language", "en"),
        category        = ai_data.get("category"),
        priority        = ai_data.get("priority", "MEDIUM"),
        ai_confidence   = ai_data.get("confidence", 0.0),
        is_duplicate    = ai_data.get("is_duplicate", False),
        duplicate_of    = ai_data.get("duplicate_of"),
        routed_dept     = ai_data.get("department"),
        routed_at       = datetime.utcnow() if ai_data.get("department") else None,
        latitude        = latitude,
        longitude       = longitude,
        locality        = locality,
        image_path      = image_path,
        status          = "pending",
    )
    db.add(complaint)
    db.flush()  # get complaint.id

    # Seed first status history entry
    db.add(StatusHistory(
        complaint_id = complaint.id,
        status       = "pending",
        note         = "Complaint received and classified by AI.",
        changed_by   = "AI System",
    ))

    # Save AI result detail
    db.add(AIResult(
        complaint_id       = complaint.id,
        predicted_category = ai_data.get("category"),
        predicted_priority = ai_data.get("priority", "MEDIUM"),
        confidence         = ai_data.get("confidence", 0.0),
        sentiment_score    = ai_data.get("sentiment"),
        keywords           = ai_data.get("keywords", []),
    ))

    db.commit()
    db.refresh(complaint)
    return complaint


# ── Read ───────────────────────────────────────────────────────────────────

def get_complaint_by_cid(db: Session, complaint_id: str) -> Optional[Complaint]:
    return db.query(Complaint).filter(Complaint.complaint_id == complaint_id).first()


def get_complaints_by_token(
    db: Session,
    token_id: str,
    status: Optional[str] = None,
    skip: int = 0,
    limit: int = 50,
) -> list[Complaint]:
    q = db.query(Complaint).filter(Complaint.token_id == token_id)
    if status:
        q = q.filter(Complaint.status == status)
    return q.order_by(Complaint.created_at.desc()).offset(skip).limit(limit).all()


def get_all_complaints(
    db: Session,
    status: Optional[str] = None,
    category: Optional[str] = None,
    priority: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
) -> list[Complaint]:
    q = db.query(Complaint)
    if status:
        q = q.filter(Complaint.status == status)
    if category:
        q = q.filter(Complaint.category == category)
    if priority:
        q = q.filter(Complaint.priority == priority)
    return q.order_by(Complaint.created_at.desc()).offset(skip).limit(limit).all()


def get_kpi_stats(db: Session) -> dict:
    total    = db.query(func.count(Complaint.id)).scalar()
    pending  = db.query(func.count(Complaint.id)).filter(Complaint.status == "pending").scalar()
    resolved = db.query(func.count(Complaint.id)).filter(Complaint.status == "resolved").scalar()
    critical = db.query(func.count(Complaint.id)).filter(Complaint.priority == "CRITICAL").scalar()
    return {"total": total, "pending": pending, "resolved": resolved, "critical": critical}


# ── Update ─────────────────────────────────────────────────────────────────

def update_complaint_status(
    db: Session,
    complaint_id: str,
    new_status: str,
    admin_username: str,
    note: Optional[str] = None,
) -> Optional[Complaint]:
    complaint = db.query(Complaint).filter(Complaint.complaint_id == complaint_id).first()
    if not complaint:
        return None
    complaint.status     = new_status
    complaint.updated_at = datetime.utcnow()
    if new_status == "escalated":
        complaint.escalated = True
        complaint.escalation_count = str(int(complaint.escalation_count or "0") + 1)

    db.add(StatusHistory(
        complaint_id = complaint.id,
        status       = new_status,
        note         = note or f"Status updated to {new_status}.",
        changed_by   = admin_username,
    ))
    db.commit()
    db.refresh(complaint)
    return complaint


def save_ai_feedback(
    db: Session,
    complaint_id: str,
    corrected_category: Optional[str],
    corrected_priority: Optional[str],
    flag_reason: Optional[str],
) -> bool:
    complaint = db.query(Complaint).filter(Complaint.complaint_id == complaint_id).first()
    if not complaint or not complaint.ai_result:
        return False
    ai = complaint.ai_result
    if corrected_category:
        ai.corrected_category = corrected_category
        complaint.category    = corrected_category
    if corrected_priority:
        ai.corrected_priority = corrected_priority
        complaint.priority    = corrected_priority
    if flag_reason:
        ai.is_flagged  = True
        ai.flag_reason = flag_reason
    db.commit()
    return True
