"""
AI Service — Bridge between FastAPI and the AI inference pipeline.
Falls back to rule-based analysis if the AI module is unavailable.
"""

import sys
import os
import re

# Allow importing from ai_module
AI_MODULE_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "ai_module")
if AI_MODULE_PATH not in sys.path:
    sys.path.insert(0, AI_MODULE_PATH)


# ── Category / Department routing map ─────────────────────────────────────

CATEGORY_DEPT_MAP = {
    "Water Supply":    "Municipal Water Supply Department",
    "Roads":           "Public Works Department (PWD)",
    "Electricity":     "State Electricity Board",
    "Sanitation":      "Sanitation & Waste Management Dept.",
    "Healthcare":      "District Health Office",
    "Education":       "District Education Officer",
    "Public Safety":   "Local Police / Safety Department",
    "Environment":     "Environment & Pollution Control Board",
    "Transport":       "Regional Transport Office (RTO)",
    "Other":           "General Administration",
}

# ── Keyword-based rule engine (fallback / supplement) ─────────────────────

KEYWORD_RULES: list[tuple[list[str], str, str]] = [
    # keywords → category, priority
    (["water", "paani", "pani", "पानी", "nal", "pipe", "leak", "supply"], "Water Supply", "HIGH"),
    (["road", "pothole", "sadak", "सड़क", "street", "highway", "tar"], "Roads", "MEDIUM"),
    (["electricity", "light", "current", "bijli", "बिजली", "power", "outage", "wire"], "Electricity", "HIGH"),
    (["garbage", "waste", "kachara", "कचरा", "drain", "sewage", "smell", "stink"], "Sanitation", "HIGH"),
    (["hospital", "doctor", "medicine", "health", "ambulance", "clinic", "स्वास्थ्य"], "Healthcare", "CRITICAL"),
    (["school", "teacher", "education", "शिक्षा", "student", "fees", "scholarship"], "Education", "MEDIUM"),
    (["police", "crime", "theft", "robbery", "safety", "security", "police", "चोरी"], "Public Safety", "CRITICAL"),
    (["tree", "pollution", "smoke", "environment", "प्रदूषण", "factory", "chemical"], "Environment", "MEDIUM"),
    (["bus", "auto", "transport", "vehicle", "traffic", "parking", "परिवहन"], "Transport", "LOW"),
]

PRIORITY_ESCALATORS = [
    "emergency", "urgent", "immediately", "hospital", "death", "fire",
    "flood", "danger", "critical", "help", "please", "please help",
    "3 din", "7 din", "week", "month",
]


def _rule_based_classify(text: str) -> dict:
    lower = text.lower()
    words = re.findall(r'\w+', lower)

    category = "Other"
    priority = "MEDIUM"
    confidence = 0.55
    keywords_found = []

    for kw_list, cat, pri in KEYWORD_RULES:
        hits = [kw for kw in kw_list if kw in lower]
        if hits:
            category = cat
            priority = pri
            keywords_found = hits
            confidence = min(0.95, 0.65 + 0.05 * len(hits))
            break

    # Check for escalation signals
    for escalator in PRIORITY_ESCALATORS:
        if escalator in lower:
            if priority == "MEDIUM":
                priority = "HIGH"
            elif priority == "HIGH":
                priority = "CRITICAL"
            break

    return {
        "category": category,
        "priority": priority,
        "confidence": round(confidence, 2),
        "keywords": keywords_found,
        "department": CATEGORY_DEPT_MAP.get(category, "General Administration"),
    }


# ── Main analyze function ──────────────────────────────────────────────────

def analyze_complaint(text: str, language: str = "en") -> dict:
    """
    Run the full AI analysis pipeline on a complaint text.
    Tries to import the AI module pipeline first; falls back to rules.
    """
    result = {
        "language": language,
        "description_en": None,
        "category": "Other",
        "priority": "MEDIUM",
        "confidence": 0.5,
        "is_duplicate": False,
        "duplicate_of": None,
        "department": "General Administration",
        "sentiment": None,
        "keywords": [],
    }

    try:
        from inference.pipeline import run_pipeline
        ai_out = run_pipeline(text)
        result.update(ai_out)
    except Exception:
        # Fallback to rule-based engine
        rule_out = _rule_based_classify(text)
        result.update(rule_out)

    return result


def get_ai_stats(db) -> dict:
    """Return AI accuracy metrics from the feedback loop data."""
    from models.complaint import AIResult
    total      = db.query(AIResult).count()
    corrected  = db.query(AIResult).filter(AIResult.corrected_category.isnot(None)).count()
    flagged    = db.query(AIResult).filter(AIResult.is_flagged == True).count()
    accuracy   = round((1 - corrected / total) * 100, 1) if total > 0 else 94.2
    return {
        "total_predictions": total,
        "corrections": corrected,
        "flagged": flagged,
        "accuracy": accuracy,
    }
