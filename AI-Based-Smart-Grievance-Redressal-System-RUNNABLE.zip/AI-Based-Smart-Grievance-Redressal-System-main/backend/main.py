"""
AI-Based Smart Grievance Redressal System
FastAPI Backend — Entry Point
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from routes.auth import router as auth_router
from routes.otp import router as otp_router
from routes.complaints import router as complaints_router
from routes.ai import router as ai_router
from routes.notices import router as notices_router
from database import engine, Base

# Import all models so their tables are registered with Base
import models.user       # noqa: F401
import models.complaint  # noqa: F401
import models.notice     # noqa: F401

# Create DB tables (including new columns)
Base.metadata.create_all(bind=engine)

# Ensure upload directories exist
os.makedirs("uploads",          exist_ok=True)
os.makedirs("uploads/videos",   exist_ok=True)
os.makedirs("uploads/notices",  exist_ok=True)

app = FastAPI(
    title="AI-Based Smart Grievance Redressal System",
    description="Automates citizen complaint classification, prioritization, and routing using AI.",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS — allow frontend dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files — images, videos, notice photos
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# Register routers
app.include_router(auth_router,       prefix="/api/auth",       tags=["Authentication"])
app.include_router(otp_router,        prefix="/api/auth/otp",   tags=["OTP Auth"])
app.include_router(complaints_router, prefix="/api/complaints", tags=["Complaints"])
app.include_router(ai_router,         prefix="/api/ai",         tags=["AI Services"])
app.include_router(notices_router,    prefix="/api/notices",    tags=["Notices"])

@app.get("/api/health", tags=["Health"])
def health_check():
    return {"status": "healthy", "database": "connected"}

# Serve the frontend files
frontend_path = os.path.join(os.path.dirname(__file__), "..", "frontend")
app.mount("/", StaticFiles(directory=frontend_path, html=True), name="frontend")
