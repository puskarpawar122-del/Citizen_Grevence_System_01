"""
SQLAlchemy Models — Citizen Token, Phone OTP & Admin User
"""

import uuid
from datetime import datetime
from sqlalchemy import Column, String, Boolean, DateTime, Text
from database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


class CitizenToken(Base):
    """
    A randomly generated anonymous token issued to citizens.
    No personal data is ever stored alongside it.
    """
    __tablename__ = "citizen_tokens"

    id          = Column(String, primary_key=True, default=_uuid)
    token       = Column(String, unique=True, nullable=False, index=True)
    created_at  = Column(DateTime, default=datetime.utcnow)
    last_login  = Column(DateTime, nullable=True)
    is_active   = Column(Boolean, default=True)


class AdminUser(Base):
    """
    Administrative user — credentials are hashed.
    """
    __tablename__ = "admin_users"

    id              = Column(String, primary_key=True, default=_uuid)
    username        = Column(String, unique=True, nullable=False, index=True)
    hashed_password = Column(String, nullable=False)
    full_name       = Column(String, nullable=True)
    department      = Column(String, nullable=True)
    created_at      = Column(DateTime, default=datetime.utcnow)
    is_active       = Column(Boolean, default=True)
    is_superadmin   = Column(Boolean, default=False)


class PhoneToken(Base):
    """
    Links a hashed phone number to an anonymous citizen token.
    Used for OTP-based login. Phone is never stored in plaintext.
    """
    __tablename__ = "phone_tokens"

    id              = Column(String, primary_key=True, default=_uuid)
    phone_hash      = Column(String, unique=True, nullable=False, index=True)  # SHA-256 of E.164 phone
    citizen_token   = Column(String, nullable=False, index=True)                # linked anonymous token

    # OTP fields (cleared after successful verify)
    otp_hash        = Column(String, nullable=True)     # bcrypt of the 6-digit OTP
    otp_expires_at  = Column(DateTime, nullable=True)
    otp_attempts    = Column(Text, default="0")          # track brute-force

    verified        = Column(Boolean, default=False)
    created_at      = Column(DateTime, default=datetime.utcnow)
    last_login      = Column(DateTime, nullable=True)
