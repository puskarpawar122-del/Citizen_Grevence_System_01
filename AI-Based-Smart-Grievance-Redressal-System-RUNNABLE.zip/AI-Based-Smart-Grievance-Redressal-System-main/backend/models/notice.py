"""
SQLAlchemy Model — Early Notice (Supervisor Broadcasts)
"""

import uuid
from datetime import datetime
from sqlalchemy import Column, String, Boolean, DateTime, Text
from database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


class Notice(Base):
    """
    Supervisor/Admin broadcast notices to citizens.
    Can be targeted to a specific ward/zone or visible to all.
    """
    __tablename__ = "notices"

    id          = Column(String, primary_key=True, default=_uuid)
    title       = Column(String(300), nullable=False)
    message     = Column(Text, nullable=False)

    # Severity: info | warning | critical
    severity    = Column(String(20), default="info")

    # Ward/zone targeting — blank means broadcast to all
    ward_tag    = Column(String(200), nullable=True)   # e.g. "Ward 42"
    zone_tag    = Column(String(200), nullable=True)   # e.g. "North Zone"

    # Optional supervisor-uploaded evidence (photo or video)
    photo_path  = Column(String(500), nullable=True)
    video_path  = Column(String(500), nullable=True)

    # Lifecycle
    created_by  = Column(String(200), nullable=False)  # admin username
    is_active   = Column(Boolean, default=True)
    expires_at  = Column(DateTime, nullable=True)

    created_at  = Column(DateTime, default=datetime.utcnow)
    updated_at  = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
