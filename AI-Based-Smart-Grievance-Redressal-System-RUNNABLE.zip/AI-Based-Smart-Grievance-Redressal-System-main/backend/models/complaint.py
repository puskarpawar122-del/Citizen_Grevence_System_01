"""
SQLAlchemy Models — Complaint, StatusHistory, AIResult
"""

import uuid
from datetime import datetime
from sqlalchemy import (
    Column, String, Float, Boolean, DateTime, Text, ForeignKey, JSON
)
from sqlalchemy.orm import relationship
from database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


class Complaint(Base):
    __tablename__ = "complaints"

    id              = Column(String, primary_key=True, default=_uuid)
    complaint_id    = Column(String, unique=True, nullable=False, index=True)   # e.g. CMP-2024-00001
    token_id        = Column(String, nullable=False, index=True)                 # anonymous link

    # Raw text (multilingual)
    description     = Column(Text, nullable=False)
    description_en  = Column(Text, nullable=True)     # translated if not English
    detected_lang   = Column(String(20), default="en")

    # AI classification results
    category        = Column(String(100), nullable=True)   # Water Supply, Roads …
    priority        = Column(String(20), default="MEDIUM")  # CRITICAL/HIGH/MEDIUM/LOW
    ai_confidence   = Column(Float, default=0.0)
    is_duplicate    = Column(Boolean, default=False)
    duplicate_of    = Column(String, nullable=True)

    # Routing
    routed_dept     = Column(String(200), nullable=True)
    routed_at       = Column(DateTime, nullable=True)

    # Location
    latitude        = Column(Float, nullable=True)
    longitude       = Column(Float, nullable=True)
    locality        = Column(String(300), nullable=True)

    # Evidence — up to 4 photos + 2 videos
    image_path      = Column(String(500), nullable=True)   # photo 1
    image_path_2    = Column(String(500), nullable=True)   # photo 2
    image_path_3    = Column(String(500), nullable=True)   # photo 3
    image_path_4    = Column(String(500), nullable=True)   # photo 4
    # Per-photo GPS proof (burned on image + stored)
    photo_lat_1     = Column(Float, nullable=True)
    photo_lng_1     = Column(Float, nullable=True)
    photo_lat_2     = Column(Float, nullable=True)
    photo_lng_2     = Column(Float, nullable=True)
    photo_lat_3     = Column(Float, nullable=True)
    photo_lng_3     = Column(Float, nullable=True)
    photo_lat_4     = Column(Float, nullable=True)
    photo_lng_4     = Column(Float, nullable=True)
    video_path      = Column(String(500), nullable=True)   # video 1
    video_path_2    = Column(String(500), nullable=True)   # video 2

    # Lifecycle
    status          = Column(String(30), default="pending")   # pending/in_progress/resolved/escalated/denied
    denial_reason   = Column(String(500), nullable=True)       # populated when denied
    escalated       = Column(Boolean, default=False)
    escalation_count = Column(String, default="0")

    created_at      = Column(DateTime, default=datetime.utcnow)
    updated_at      = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    history         = relationship("StatusHistory", back_populates="complaint", cascade="all, delete")
    ai_result       = relationship("AIResult", back_populates="complaint", uselist=False, cascade="all, delete")


class StatusHistory(Base):
    __tablename__ = "status_history"

    id           = Column(String, primary_key=True, default=_uuid)
    complaint_id = Column(String, ForeignKey("complaints.id"), nullable=False)
    status       = Column(String(30), nullable=False)
    note         = Column(Text, nullable=True)
    changed_by   = Column(String(200), nullable=True)   # admin username or "AI System"
    changed_at   = Column(DateTime, default=datetime.utcnow)

    complaint    = relationship("Complaint", back_populates="history")


class AIResult(Base):
    """
    Stores raw AI pipeline output for feedback loop corrections.
    """
    __tablename__ = "ai_results"

    id                  = Column(String, primary_key=True, default=_uuid)
    complaint_id        = Column(String, ForeignKey("complaints.id"), nullable=False)

    # Original predictions
    predicted_category  = Column(String(100))
    predicted_priority  = Column(String(20))
    confidence          = Column(Float)
    sentiment_score     = Column(Float, nullable=True)
    keywords            = Column(JSON, nullable=True)    # list of extracted keywords

    # Feedback corrections (admin)
    corrected_category  = Column(String(100), nullable=True)
    corrected_priority  = Column(String(20), nullable=True)
    is_flagged          = Column(Boolean, default=False)
    flag_reason         = Column(Text, nullable=True)

    created_at          = Column(DateTime, default=datetime.utcnow)

    complaint           = relationship("Complaint", back_populates="ai_result")
