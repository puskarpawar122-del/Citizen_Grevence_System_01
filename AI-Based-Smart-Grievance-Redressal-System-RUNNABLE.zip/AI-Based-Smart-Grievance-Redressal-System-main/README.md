# NyayaVaani — AI-Based Smart Grievance Redressal System

> **"Your Voice, Heard & Resolved"** — An AI-powered civic complaint portal with multilingual support, anonymous identity protection, and intelligent routing.

---

## 🚀 Quick Start

### 1. Backend (FastAPI)
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```
Backend → `http://localhost:8000`  |  API Docs → `http://localhost:8000/docs`

### 2. Frontend
Open `frontend/index.html` in any browser — **no build step needed**.

The frontend **auto-detects** the backend:
- **Backend running** → real API calls
- **Backend offline** → demo mode with sample data

### 3. Demo Login
| Role | Credential |
|------|-----------|
| Citizen | Generate a token on the Register page |
| Admin | `admin` / `admin123` |

---

## 📁 Project Structure
```
├── frontend/
│   ├── index.html          ← SPA shell + all page templates
│   ├── css/style.css       ← Full design system (dark, glassmorphism)
│   └── js/
│       ├── store.js        ← Global state
│       ├── api.js          ← API client + auto demo-mode
│       ├── ai.js           ← Real-time AI analysis panel
│       ├── router.js       ← SPA page router
│       ├── auth.js         ← Login / register / logout
│       ├── citizen.js      ← Complaint form, list, tracking
│       ├── admin.js        ← Dashboard, charts, routing map
│       └── app.js          ← Entry point
│
├── backend/
│   ├── main.py             ← FastAPI + CORS + routes
│   ├── database.py         ← SQLAlchemy config
│   ├── requirements.txt
│   ├── models/             ← SQLAlchemy ORM models
│   ├── routes/             ← API route handlers
│   ├── controllers/        ← Business logic layer
│   ├── services/           ← DB operations + AI bridge
│   └── middleware/         ← JWT auth middleware
│
└── ai_module/
    ├── language_detection/ ← Multilingual script detector
    ├── preprocessing/      ← Text normalization
    ├── model/              ← Rule-based + XLM-RoBERTa classifier
    ├── inference/          ← Full AI pipeline
    └── training/           ← Fine-tuning script
```

---

## 🔑 API Reference

| Endpoint | Method | Auth | Description |
|----------|--------|------|-------------|
| `/api/auth/token/generate` | POST | None | Get anonymous citizen token |
| `/api/auth/token/login` | POST | None | Login with token → JWT |
| `/api/auth/admin/login` | POST | None | Admin login |
| `/api/complaints/submit` | POST | Citizen | Submit complaint |
| `/api/complaints/mine` | GET | Citizen | My complaints |
| `/api/complaints/track/{id}` | GET | None | Track by ID |
| `/api/complaints/admin/all` | GET | Admin | All complaints |
| `/api/complaints/admin/kpi` | GET | Admin | KPI stats |
| `/api/complaints/admin/{id}/status` | PATCH | Admin | Update status |
| `/api/ai/analyze` | POST | None | Real-time AI analysis |
| `/api/ai/analytics` | GET | Admin | Chart data |
| `/api/ai/feedback` | POST | Admin | AI correction |

---

## 🌐 Languages: Hindi · Hinglish · English · Marathi · Telugu · Tamil · Bengali
## 📋 Categories: Water · Roads · Electricity · Sanitation · Healthcare · Education · Safety · Environment · Transport
