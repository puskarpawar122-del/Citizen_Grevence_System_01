import requests

BASE_URL = "http://localhost:8000"

def test():
    # 1. Login with OTP
    print("Logging in...")
    res = requests.post(f"{BASE_URL}/api/auth/otp/verify", json={
        "phone": "9999999999",
        "code": "123456"
    })
    if res.status_code != 200:
        print(f"Login failed: {res.status_code} {res.text}")
        return
    data = res.json()
    token = data["access_token"]
    print(f"Logged in, token: {token[:20]}...")

    # 2. Submit complaint
    print("Submitting complaint...")
    headers = {"Authorization": f"Bearer {token}"}
    files = {"description": (None, "This is a test complaint about roads in my area. They are very bad.")}
    res = requests.post(f"{BASE_URL}/api/complaints/submit", headers=headers, files=files)
    print(f"Submit status: {res.status_code}")
    print(f"Submit response: {res.text}")

if __name__ == "__main__":
    test()
