import requests

BASE_URL = "http://localhost:8000"

def test():
    # 1. Login with OTP
    res = requests.post(f"{BASE_URL}/api/auth/otp/verify", json={
        "phone": "9999999999",
        "code": "123456"
    })
    token = res.json()["access_token"]
    
    # 2. Submit with dummy video
    with open("dummy.mp4", "wb") as f:
        f.write(b"dummy video data")

    headers = {"Authorization": f"Bearer {token}"}
    files = {
        "description": (None, "This is a test complaint with a video"),
        "video_1": ("dummy.mp4", open("dummy.mp4", "rb"), "video/mp4")
    }
    
    res = requests.post(f"{BASE_URL}/api/complaints/submit", headers=headers, files=files)
    print(f"Status: {res.status_code}")
    print(f"Response: {res.text}")

if __name__ == "__main__":
    test()
