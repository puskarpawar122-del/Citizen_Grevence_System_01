@echo off
setlocal
cd /d "%~dp0backend"
echo [1/2] Installing required Python packages...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Installation failed. Check Python and internet connection.
  pause
  exit /b 1
)
echo.
echo [2/2] Starting NyayaVaani backend...
python -m uvicorn main:app --reload --port 8000
