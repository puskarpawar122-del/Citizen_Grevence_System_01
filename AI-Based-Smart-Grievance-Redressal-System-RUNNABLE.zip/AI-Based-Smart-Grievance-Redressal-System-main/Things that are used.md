# NyayaVaani — Things That Are Used

> Complete reference of every technology, library, API, tool, and design decision used in this project.

---

## 1. 🖥️ Frontend Technologies

| Technology | Version | Purpose | Where Used |
|------------|---------|---------|------------|
| **HTML5** | Native | SPA shell, `<template>` tags for pages | `frontend/index.html` |
| **CSS3 (Vanilla)** | Native | Custom design system, dark mode, glassmorphism | `frontend/css/style.css` |
| **JavaScript (ES2022)** | Native | SPA logic, routing, state, API — no framework | `frontend/js/*.js` |
| **Chart.js** | `4.4.0` CDN | 5 analytics charts (doughnut, bar, line, polar) | `admin.js` |
| **Leaflet.js** | `1.9.4` CDN | Interactive maps for location tagging & routing | `citizen.js`, `admin.js` |
| **Google Fonts — Inter** | CDN | Primary UI font (300–900 weights) | `index.html` |
| **Google Fonts — JetBrains Mono** | CDN | Monospace for tokens & complaint IDs | `index.html` |

### Frontend JS Modules
| File | Role |
|------|------|
| `store.js` | Global state (auth, complaints, drafts) |
| `api.js` | HTTP client + auto demo-mode fallback |
| `ai.js` | Debounced real-time AI panel |
| `router.js` | Template-based SPA router |
| `auth.js` | Token generation, login, logout |
| `citizen.js` | Multi-step form, map, upload, list, track |
| `admin.js` | KPI, charts, status updates, routing map |
| `app.js` | Entry point — wires all modules |

---

## 2. ⚙️ Backend Technologies

| Technology | Version | Purpose |
|------------|---------|---------|
| **Python** | `3.10+` | Core server language |
| **FastAPI** | `0.111.0` | REST API framework |
| **Uvicorn** | `0.29.0` | ASGI server |
| **SQLAlchemy** | `>=2.0.36` | ORM (Python 3.13 compatible) |
| **SQLite** | Built-in | Local development database |
| **PostgreSQL** | External | Production database |
| **PyJWT** | `2.8.0` | JWT creation & verification |
| **Passlib + bcrypt** | `1.7.4` | Admin password hashing |
| **python-multipart** | `0.0.9` | Form data + file upload parsing |
| **python-dotenv** | `1.0.1` | `.env` environment variable loading |
| **aiofiles** | `23.2.1` | Async file I/O |

### Backend Architecture
```
routes/ → controllers/ → services/ → models/
```
- **Dependency Injection** via FastAPI `Depends()` for DB + JWT
- **CORS** configured for all origins in dev
- **Static file serving** from `/uploads/`

---

## 3. 🤖 AI / Machine Learning

| Technology | Status | Purpose |
|------------|--------|---------|
| **Custom Keyword Rule Engine** | ✅ Always active | Multilingual keyword → category/priority |
| **Unicode Script Detection** | ✅ Always active | Detect Hindi, Telugu, Tamil, Bengali |
| **langdetect** `1.0.9` | ✅ Lightweight | Language identification |
| **XLM-RoBERTa** (HuggingFace) | ⚠️ Optional | Zero-shot multilingual classification |
| **HuggingFace Transformers** `4.40+` | ⚠️ Optional | ML model runtime |
| **PyTorch** `2.0+` | ⚠️ Optional | Deep learning backend |

### AI Pipeline Flow
```
Text → Language Detection → Text Cleaning → Classification
     → Priority Escalation → Department Routing → Result
```

### Languages Supported
Hindi (hi) · Hinglish · English (en) · Marathi (mr) · Telugu (te) · Tamil (ta) · Bengali (bn)

---

## 4. 🔌 APIs & External Services

| Service | Cost | API Key? | Purpose |
|---------|------|---------|---------|
| **OpenStreetMap** | Free | ❌ None | Map tiles via Leaflet |
| **Browser Geolocation API** | Free | ❌ None | Auto-detect lat/lng |
| **Render.com** | Free tier | ❌ None | Backend deployment |
| **Vercel.com** | Free tier | ❌ None | Frontend deployment |
| **Supabase** | Free tier | ❌ None | Production PostgreSQL |
| **Google Fonts** | Free | ❌ None | Inter + JetBrains Mono |
| **jsDelivr CDN** | Free | ❌ None | Chart.js |
| **unpkg CDN** | Free | ❌ None | Leaflet.js |

> ✅ **Zero paid API keys required.**

---

## 5. 🔒 Security & Privacy

| Feature | How |
|---------|-----|
| **Anonymous tokenization** | Random `NYV-YEAR-XXXXXXXXXX` — no PII stored |
| **JWT authentication** | Short-lived tokens for citizens and admins |
| **bcrypt hashing** | Admin passwords salted + hashed |
| **CORS policy** | Origin whitelist in production |
| **File validation** | Only jpg/png/webp, max 5MB |
| **SQL injection protection** | SQLAlchemy ORM (parameterized queries) |

---

## 6. 🗄️ Database Schema

| Table | Purpose |
|-------|---------|
| `citizen_tokens` | Anonymous citizen identities |
| `admin_users` | Admin accounts with bcrypt passwords |
| `complaints` | Core complaint data with AI results |
| `status_history` | Full audit trail of every status change |
| `ai_results` | AI predictions + feedback corrections |

---

## 7. 🎨 Design System

| Choice | Detail |
|--------|--------|
| Theme | Dark mode — `#050b18` background |
| Style | Glassmorphism — `backdrop-filter: blur` |
| Primary | `#4f8ef7` blue |
| Accent | `#7c3aed` purple |
| Font | Inter (UI) + JetBrains Mono (IDs) |
| Animations | Fade-in, slide-up, float, pulse, spin |

---

## 8. 🚀 Deployment Stack (All Free)

```
Browser → Vercel (Frontend) → Render (Backend) → Supabase (PostgreSQL)
```

See the `free deployment` file for step-by-step instructions.

---

*NyayaVaani v1.0.0 | May 2026*
