import requests

url = "http://127.0.0.1:8000/api/complaints/submit"

# We need a valid citizen token first.
# Bypass OTP login for 8643021846
otp_res = requests.post("http://127.0.0.1:8000/api/auth/otp/verify", json={"phone": "8643021846", "code": "123456"})
print("OTP Login:", otp_res.status_code, otp_res.text)

token = otp_res.json()["access_token"]
headers = {"Authorization": f"Bearer {token}"}

# Submit a complaint
files = {
    "description": (None, "This is a test complaint about roads and potholes with a lot of issues."),
    "latitude": (None, "20.1234"),
    "longitude": (None, "78.1234"),
    "locality": (None, "Test Locality"),
    "image_1": ("test.jpg", b"fake image content", "image/jpeg")
}

res = requests.post(url, headers=headers, files=files)
print("Submit Complaint:", res.status_code, res.text)
