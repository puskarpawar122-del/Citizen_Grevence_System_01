# NyayaVaani — Things Used

This document provides a clear explanation of the technologies, tools, and design principles used to build the **AI-Based Smart Grievance Redressal System**.

---

## 🎨 1. Frontend (The User Interface)
The frontend is built for speed, accessibility, and a premium aesthetic using a "no-framework" approach.

*   **HTML5**: Used for the structure and semantic organization of the Single Page Application (SPA).
*   **Vanilla CSS3**: A custom-built design system featuring:
    *   **Warm Beige Theme**: A sophisticated color palette (`#f5f0e8`) designed for readability and trust.
    *   **Glassmorphism**: Subtle blur effects and semi-transparent cards for a modern, layered look.
    *   **Responsive Design**: Fully optimized for mobile, tablet, and desktop screens.
*   **Vanilla JavaScript (ES2022)**: Handles all application logic, routing, and API interactions without the overhead of heavy frameworks like React or Vue.
*   **Chart.js**: Powering the Admin Dashboard with interactive analytics (Doughnut, Bar, and Line charts).
*   **Leaflet.js**: Used for interactive maps, allowing citizens to tag locations and admins to visualize complaint density.
*   **Google Fonts**: *Inter* for clean UI text and *JetBrains Mono* for system IDs.

---

## ⚙️ 2. Backend (The Engine)
The backend is a high-performance API that handles data processing, security, and AI orchestration.

*   **Python 3.10+**: The core programming language.
*   **FastAPI**: A modern, high-speed web framework for building APIs with Python. It's known for its automatic documentation and type safety.
*   **Uvicorn**: The lightning-fast ASGI server that runs the FastAPI application.
*   **SQLAlchemy**: A powerful Object-Relational Mapper (ORM) that interacts with the database using Python objects instead of raw SQL queries.
*   **SQLite**: A lightweight, file-based database used for local development (no complex setup required).
*   **PyJWT**: Handles secure, stateless authentication using JSON Web Tokens.
*   **Passlib (bcrypt)**: Ensures admin passwords are secure by using industry-standard hashing algorithms.

---

## 🤖 3. AI & Machine Learning
The "Smart" part of the system that automates classification and routing.

*   **Custom Keyword Rule Engine**: A multilingual engine that detects keywords to automatically categorize complaints and assign priority.
*   **Script Detection**: Identifies whether a complaint is written in Hindi, English, Telugu, Tamil, etc., based on Unicode characters.
*   **Langdetect**: A lightweight library for secondary language identification.
*   **XLM-RoBERTa (Optional)**: Support for advanced multilingual AI models for zero-shot classification (can be enabled for production).

---

## 🔒 4. Security & Authentication
Protecting citizen privacy while maintaining accountability.

*   **Anonymous Tokenization**: Citizens are assigned unique tokens (e.g., `NYV-2024-XXXX`) so they can report issues without exposing personal identity.
*   **JWT Sessions**: Secure, short-lived sessions for both citizens and admins.
*   **Departmental Routing**: Automated logic ensures complaints are only visible to the relevant departments (Roads, Water, Electricity, etc.).

---

## 🚀 5. Third-Party Services
External tools that enhance the application experience.

*   **OpenStreetMap**: Provides the map tiles used in the Leaflet interactive maps.
*   **Browser Geolocation API**: Allows the app to automatically detect the user's location for faster reporting.
*   **jsDelivr / unpkg**: Content Delivery Networks used to load external libraries quickly.

---
*NyayaVaani v2.0.0 | Smart Civic Engagement*
