/**
 * router.js — SPA Page Router
 * Clones HTML templates into #pageContainer and manages navigation state.
 */

const Router = (() => {
  const PAGE_CONTAINER = () => document.getElementById('pageContainer');
  const NAV_ACTIONS    = () => document.getElementById('navActions');

  // Page → template ID mapping
  const TEMPLATES = {
    landing:  'tpl-landing',
    login:    'tpl-login',
    register: 'tpl-register',
    citizen:  'tpl-citizen',
    admin:    'tpl-admin',
  };

  // Pages that require auth
  const PROTECTED = {
    citizen: 'citizen',
    admin:   'admin',
  };

  let _onPageLoad = {};  // callbacks to run after page renders

  function _updateNavbar(page) {
    const role    = Store.get('role');
    const actions = NAV_ACTIONS();
    if (!actions) return;

    if (role === 'citizen') {
      actions.innerHTML = `
        <span class="nav-token font-mono">${Store.get('citizenToken')?.slice(0,12)}...</span>
        <button class="btn btn-ghost" id="btnLogoutNav">🚪 Logout</button>
      `;
      document.getElementById('btnLogoutNav')?.addEventListener('click', () => {
        Store.clearAuth();
        navigate('landing');
      });
    } else if (role === 'admin') {
      const info = Store.get('adminInfo');
      actions.innerHTML = `
        <span class="nav-token">${info?.full_name || 'Admin'}</span>
        <button class="btn btn-ghost" id="btnLogoutNav">🚪 Logout</button>
      `;
      document.getElementById('btnLogoutNav')?.addEventListener('click', () => {
        Store.clearAuth();
        navigate('landing');
      });
    } else {
      actions.innerHTML = `
        <button class="btn btn-ghost" id="btnLogin" data-page="login">Login</button>
        <button class="btn btn-primary" id="btnRegister" data-page="register">File Complaint</button>
      `;
    }
  }

  function navigate(page) {
    const role = Store.get('role');

    // Guard: redirect logged-in users away from auth pages
    if ((page === 'login' || page === 'register') && role === 'citizen') {
      page = 'citizen';
    }
    if ((page === 'login' || page === 'register') && role === 'admin') {
      page = 'admin';
    }

    // Guard: protect citizen/admin pages
    if (page === 'citizen' && role !== 'citizen') { page = 'login'; }
    if (page === 'admin'   && role !== 'admin')   { page = 'login'; }

    const tplId = TEMPLATES[page] || TEMPLATES['landing'];
    const tpl   = document.getElementById(tplId);
    if (!tpl) return;

    const container = PAGE_CONTAINER();
    container.innerHTML = '';
    container.appendChild(tpl.content.cloneNode(true));

    Store.set('currentPage', page);
    window.scrollTo(0, 0);
    _updateNavbar(page);

    // Run page init callback if registered
    if (_onPageLoad[page]) _onPageLoad[page]();
  }

  function onLoad(page, fn) {
    _onPageLoad[page] = fn;
  }

  // Global click delegation for [data-page] and [data-section] elements
  function _globalClickHandler(e) {
    const pageBtn = e.target.closest('[data-page]');
    if (pageBtn) {
      e.preventDefault();
      navigate(pageBtn.dataset.page);
      return;
    }
    const sectionBtn = e.target.closest('[data-section]');
    if (sectionBtn) {
      e.preventDefault();
      const sec = sectionBtn.dataset.section;
      _switchSection(sec);
    }
  }

  function _switchSection(section) {
    // Sidebar links
    document.querySelectorAll('.sidebar-link').forEach(l => {
      l.classList.toggle('active', l.dataset.section === section);
    });
    // Section content panels
    document.querySelectorAll('.section-content').forEach(s => {
      s.classList.toggle('active', s.id === `section-${section}`);
      s.classList.toggle('hidden',  s.id !== `section-${section}`);
    });
    Store.set('currentSection', section);
    // Trigger section-specific init
    if (_onPageLoad[`section:${section}`]) _onPageLoad[`section:${section}`]();
  }

  function registerSectionCallback(section, fn) {
    _onPageLoad[`section:${section}`] = fn;
  }

  function init() {
    document.addEventListener('click', _globalClickHandler);

    // Navbar scroll effect
    window.addEventListener('scroll', () => {
      const nav = document.getElementById('navbar');
      if (nav) nav.classList.toggle('scrolled', window.scrollY > 40);
    });

    // Hamburger
    document.getElementById('hamburger')?.addEventListener('click', () => {
      const links = document.getElementById('navLinks');
      if (links) links.classList.toggle('open');
    });

    // Load correct initial page
    const role = Store.get('role');
    if (role === 'citizen') navigate('citizen');
    else if (role === 'admin') navigate('admin');
    else navigate('landing');
  }

  return { navigate, onLoad, registerSectionCallback, init };
})();
