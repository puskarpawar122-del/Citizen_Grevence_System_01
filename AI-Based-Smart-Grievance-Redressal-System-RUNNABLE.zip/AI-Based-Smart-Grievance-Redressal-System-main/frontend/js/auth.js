/**
 * auth.js — OTP-based Login and Admin Login flows
 * Token-based anonymous login has been replaced by Mobile OTP.
 */

const Auth = (() => {

  // ── Toast helper ────────────────────────────────────────────────────────
  function toast(msg, type = 'info') {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = msg;
    el.className   = `toast toast-${type}`;
    el.classList.remove('hidden');
    setTimeout(() => el.classList.add('hidden'), 3500);
  }

  // ── OTP Login page ─────────────────────────────────────────────────────
  function initLoginPage() {
    const tabOtp   = document.getElementById('tabOtp');
    const tabAdmin = document.getElementById('tabAdmin');
    const otpForm  = document.getElementById('otpLoginForm');
    const adminForm= document.getElementById('adminLoginForm');

    // Tab switching
    tabOtp?.addEventListener('click', () => {
      tabOtp.classList.add('active');
      tabAdmin.classList.remove('active');
      otpForm?.classList.remove('hidden');
      adminForm?.classList.add('hidden');
    });
    tabAdmin?.addEventListener('click', () => {
      tabAdmin.classList.add('active');
      tabOtp.classList.remove('active');
      adminForm?.classList.remove('hidden');
      otpForm?.classList.add('hidden');
    });

    _initOtpFlow();
    _initAdminFlow();
  }

  // ── OTP Flow ───────────────────────────────────────────────────────────
  function _initOtpFlow() {
    const phoneInput  = document.getElementById('phoneInput');
    const btnSendOtp  = document.getElementById('btnSendOtp');
    const otpStep1    = document.getElementById('otpStep1');
    const otpStep2    = document.getElementById('otpStep2');
    const otpInputEl  = document.getElementById('otpInput');
    const btnVerifyOtp= document.getElementById('btnVerifyOtp');
    const btnChangeNum= document.getElementById('btnChangeNum');
    const otpPhoneDisp= document.getElementById('otpPhoneDisplay');

    let _pendingPhone = '';

    btnSendOtp?.addEventListener('click', async () => {
      const phone = phoneInput?.value.trim();
      if (!phone || phone.length < 10) {
        toast('Enter a valid mobile number', 'warn'); return;
      }
      // Normalise to E.164-ish
      const norm = phone.startsWith('+') ? phone : `+91${phone.replace(/^0/, '')}`;

      btnSendOtp.disabled = true;
      btnSendOtp.textContent = '⏳ Sending...';

      try {
        await Api.auth.sendOtp(norm);
        toast('📱 OTP sent to your mobile number!', 'success');
        _pendingPhone = norm;
        if (otpPhoneDisp) otpPhoneDisp.textContent = norm.slice(0,4) + '****' + norm.slice(-3);
        otpStep1?.classList.add('hidden');
        otpStep2?.classList.remove('hidden');
        otpInputEl?.focus();
      } catch (err) {
        toast('Failed to send OTP: ' + err.message, 'error');
      } finally {
        btnSendOtp.disabled = false;
        btnSendOtp.textContent = '📲 Send OTP';
      }
    });

    btnChangeNum?.addEventListener('click', () => {
      otpStep2?.classList.add('hidden');
      otpStep1?.classList.remove('hidden');
      if (phoneInput) phoneInput.value = '';
      if (otpInputEl) otpInputEl.value = '';
      _pendingPhone = '';
    });

    // OTP digit auto-jump & paste support
    const otpDigits = document.querySelectorAll('.otp-digit');
    otpDigits.forEach((inp, i) => {
      inp.addEventListener('input', (e) => {
        inp.value = inp.value.replace(/\D/g, '').slice(-1);
        if (inp.value && i < otpDigits.length - 1) otpDigits[i+1].focus();
        _syncOtpInput(otpDigits, otpInputEl);
      });
      inp.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !inp.value && i > 0) otpDigits[i-1].focus();
      });
    });
    // Paste support on first digit
    otpDigits[0]?.addEventListener('paste', (e) => {
      e.preventDefault();
      const paste = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, 6);
      paste.split('').forEach((ch, i) => { if (otpDigits[i]) otpDigits[i].value = ch; });
      if (otpInputEl) otpInputEl.value = paste;
      otpDigits[Math.min(paste.length, otpDigits.length - 1)]?.focus();
    });

    btnVerifyOtp?.addEventListener('click', async () => {
      const code = _collectOtp(otpDigits);
      if (code.length !== 6) { toast('Enter the 6-digit OTP', 'warn'); return; }
      btnVerifyOtp.disabled = true;
      btnVerifyOtp.textContent = '⏳ Verifying...';

      try {
        const data = await Api.auth.verifyOtp(_pendingPhone, code);
        const jwt = data.access_token;
        const citizenToken = data.citizen_token;
        Store.setAuth({ role: 'citizen', citizenToken, accessToken: jwt });
        toast('Welcome! Logged in successfully ✅', 'success');
        Router.navigate('citizen');
      } catch (err) {
        toast(err.message, 'error');
        // Shake OTP inputs on error
        otpDigits.forEach(d => { d.classList.add('otp-error'); setTimeout(() => d.classList.remove('otp-error'), 600); });
      } finally {
        btnVerifyOtp.disabled = false;
        btnVerifyOtp.textContent = '✅ Verify & Login';
      }
    });
  }

  function _collectOtp(digits) {
    return Array.from(digits).map(d => d.value).join('');
  }
  function _syncOtpInput(digits, hidden) {
    if (hidden) hidden.value = _collectOtp(digits);
  }

  // ── Admin flow ─────────────────────────────────────────────────────────
  function _initAdminFlow() {
    const btnAdmin = document.getElementById('btnAdminLogin');
    btnAdmin?.addEventListener('click', async () => {
      const username = document.getElementById('adminUsername')?.value.trim();
      const password = document.getElementById('adminPassword')?.value;
      if (!username || !password) { toast('Enter username and password', 'warn'); return; }
      await _loginAdmin(username, password);
    });
  }

  async function _loginAdmin(username, password) {
    try {
      const data = await Api.auth.adminLogin(username, password);
      const jwt = data.access_token;
      const adminInfo = data.admin;
      Store.setAuth({ role: 'admin', accessToken: jwt, adminInfo });
      toast(`Welcome, ${adminInfo.full_name}! 🛡️`, 'success');
      Router.navigate('admin');
    } catch (err) {
      toast('Admin login failed: ' + err.message, 'error');
    }
  }

  return { initLoginPage };
})();
