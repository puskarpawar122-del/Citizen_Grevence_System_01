/**
 * citizen.js — Citizen Dashboard
 * Multi-step form (with Camera, Canvas GPS watermark, Multi-video), list, tracking, notices.
 */

const Citizen = (() => {

  function toast(msg, type = 'info') {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = msg;
    el.className   = `toast toast-${type}`;
    el.classList.remove('hidden');
    setTimeout(() => el.classList.add('hidden'), 3500);
  }

  const PRIORITY_BADGE = {
    CRITICAL: '<span class="badge badge-critical">🔴 CRITICAL</span>',
    HIGH:     '<span class="badge badge-high">🟠 HIGH</span>',
    MEDIUM:   '<span class="badge badge-medium">🔵 MEDIUM</span>',
    LOW:      '<span class="badge badge-low">🟢 LOW</span>',
  };

  const STATUS_BADGE = {
    pending:     '<span class="status-badge status-pending">⏳ Pending</span>',
    in_progress: '<span class="status-badge status-progress">🔄 In Progress</span>',
    resolved:    '<span class="status-badge status-resolved">✅ Resolved</span>',
    escalated:   '<span class="status-badge status-escalated">🚨 Escalated</span>',
    denied:      '<span class="status-badge status-denied">🚫 Denied</span>',
  };

  function _fmtDate(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });
  }

  // ── Multi-step form ───────────────────────────────────────────────────────
  let _currentStep = 1;
  let _map = null;
  let _marker = null;
  let _cameraStream = null;

  function _showStep(n) {
    for (let i = 1; i <= 4; i++) {
      const step = document.getElementById(`formStep${i}`);
      if (step) {
        step.classList.toggle('active', i === n);
        step.classList.toggle('hidden', i !== n);
      }
      const dot = document.querySelector(`.step-item[data-step="${i}"]`);
      if (dot) {
        dot.classList.toggle('active',    i === n);
        dot.classList.toggle('completed', i < n);
      }
    }
    _currentStep = n;
  }

  function _initMap() {
    if (_map) return;
    try {
      _map = L.map('complaintMap').setView([20.5937, 78.9629], 5);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(_map);
      _map.on('click', (e) => _setMapPin(e.latlng.lat, e.latlng.lng));
    } catch (_) {}
  }

  function _setMapPin(lat, lng) {
    if (!_map) return;
    if (_marker) _map.removeLayer(_marker);
    _marker = L.marker([lat, lng], { draggable: true }).addTo(_map);
    _marker.on('dragend', (e) => {
      const p = e.target.getLatLng();
      _updateLocationDisplay(p.lat, p.lng);
    });
    _updateLocationDisplay(lat, lng);
  }

  function _updateLocationDisplay(lat, lng) {
    const draft = Store.get('complaintDraft') || {};
    Store.set('complaintDraft', { ...draft, latitude: lat, longitude: lng });
    const coordsEl = document.getElementById('locationCoords');
    if (coordsEl) coordsEl.textContent = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
  }

  function _buildReview() {
    const draft  = Store.get('complaintDraft');
    const ai     = draft.aiAnalysis || {};
    const grid   = document.getElementById('reviewGrid');
    if (!grid) return;

    const photosCount = (draft.photos || []).length;
    const videosCount = (draft.videos || []).filter(v => v !== null).length;

    grid.innerHTML = `
      <div class="review-item">
        <span class="review-label">Description</span>
        <span class="review-value">${draft.description?.slice(0, 120) || '—'}...</span>
      </div>
      <div class="review-item">
        <span class="review-label">Category (AI)</span>
        <span class="review-value">${ai.category || '—'}</span>
      </div>
      <div class="review-item">
        <span class="review-label">Location</span>
        <span class="review-value">${draft.latitude ? `${draft.latitude.toFixed(4)}, ${draft.longitude.toFixed(4)}` : 'Not set'}</span>
      </div>
      <div class="review-item">
        <span class="review-label">Evidence</span>
        <span class="review-value">📷 ${photosCount} Photos, 🎥 ${videosCount} Videos</span>
      </div>
    `;
  }

  async function _submitComplaint() {
    const draft   = Store.get('complaintDraft');
    const spinner = document.getElementById('submitSpinner');
    const btn     = document.getElementById('btnSubmitComplaint');
    if (btn) btn.disabled = true;
    if (spinner) spinner.classList.remove('hidden');

    try {
      const formData = new FormData();
      formData.append('description', draft.description);
      if (draft.latitude)  formData.append('latitude',  draft.latitude);
      if (draft.longitude) formData.append('longitude', draft.longitude);
      if (draft.locality)  formData.append('locality',  draft.locality);
      
      const photos = draft.photos || [];
      for (let i = 0; i < photos.length; i++) {
        formData.append(`image_${i+1}`, photos[i].file);
        if (photos[i].lat) formData.append(`photo_lat_${i+1}`, photos[i].lat);
        if (photos[i].lng) formData.append(`photo_lng_${i+1}`, photos[i].lng);
      }
      
      const videos = draft.videos || [];
      if (videos[0]) formData.append('video_1', videos[0]);
      if (videos[1]) formData.append('video_2', videos[1]);

      const res = await Api.complaints.submit(formData);
      const complaint = res.complaint;

      _showSubmitSuccess(complaint);
      Store.set('complaintDraft', { description:'', photos:[], videos:[null, null] });
      _currentStep = 1;

    } catch (err) {
      toast('Submission failed: ' + err.message, 'error');
    } finally {
      if (btn)     btn.disabled = false;
      if (spinner) spinner.classList.add('hidden');
    }
  }

  function _showSubmitSuccess(complaint) {
    const formCard = document.querySelector('#formStep4 .form-card');
    if (!formCard) return;
    formCard.innerHTML = `
      <div class="success-screen">
        <div class="success-icon">✅</div>
        <h3>Complaint Filed Successfully!</h3>
        <p>Your complaint has been received and classified by AI.</p>
        <div class="success-id">
          <span>Complaint ID:</span>
          <code class="font-mono">${complaint.id}</code>
        </div>
        <div class="btn-row mt-16">
          <button class="btn btn-outline" data-section="history">📋 View My Complaints</button>
          <button class="btn btn-primary" onClick="window.location.reload()">+ New Complaint</button>
        </div>
      </div>
    `;
  }

  // ── Step 3: Evidence (Camera + Videos) ──────────────────────────────────
  function _initEvidence() {
    Store.set('complaintDraft', { ...Store.get('complaintDraft'), photos: [], videos: [null, null] });

    // Photos
    const btnOpenCam = document.getElementById('btnOpenCamera');
    const container  = document.getElementById('cameraPreviewContainer');
    const video      = document.getElementById('cameraVideo');
    const btnCapture = document.getElementById('btnCapturePhoto');
    const canvas     = document.getElementById('photoCanvas');
    const grid       = document.getElementById('photoPreviewGrid');

    btnOpenCam?.addEventListener('click', async () => {
      try {
        _cameraStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        video.srcObject = _cameraStream;
        container.classList.remove('hidden');
        btnOpenCam.classList.add('hidden');
      } catch (err) {
        toast('Camera access denied or unavailable', 'error');
      }
    });

    btnCapture?.addEventListener('click', async () => {
      const draft = Store.get('complaintDraft');
      if ((draft.photos || []).length >= 4) { toast('Maximum 4 photos allowed', 'warn'); return; }

      // Get GPS
      let lat = null, lng = null;
      try {
        const pos = await new Promise((resolve, reject) => navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 5000 }));
        lat = pos.coords.latitude;
        lng = pos.coords.longitude;
      } catch (e) {
        toast('Could not fetch GPS for photo', 'warn');
      }

      // Draw to canvas
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0);

      // Burn GPS & Date watermark
      const dateStr = new Date().toLocaleString();
      const locStr = lat && lng ? `GPS: ${lat.toFixed(5)}, ${lng.toFixed(5)}` : 'GPS: Unavailable';
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.fillRect(10, canvas.height - 70, 350, 60);
      ctx.font = '20px sans-serif';
      ctx.fillStyle = 'white';
      ctx.fillText(dateStr, 20, canvas.height - 40);
      ctx.fillText(locStr, 20, canvas.height - 15);

      canvas.toBlob((blob) => {
        const file = new File([blob], `photo_${Date.now()}.jpg`, { type: 'image/jpeg' });
        const url = URL.createObjectURL(blob);
        const newPhotos = [...(draft.photos || []), { file, url, lat, lng }];
        Store.set('complaintDraft', { ...draft, photos: newPhotos });
        _renderPhotoGrid();
        
        if (newPhotos.length >= 4) {
          _cameraStream.getTracks().forEach(t => t.stop());
          container.classList.add('hidden');
        }
      }, 'image/jpeg', 0.85);
    });

    // Upload photos manually
    const btnUploadPhotos = document.getElementById('btnUploadPhotos');
    const photosInput     = document.getElementById('photosInput');
    
    btnUploadPhotos?.addEventListener('click', () => photosInput?.click());
    photosInput?.addEventListener('change', (e) => {
      const files = e.target.files;
      if (!files.length) return;
      const draft = Store.get('complaintDraft');
      let newPhotos = [...(draft.photos || [])];

      for (let i = 0; i < files.length; i++) {
        if (newPhotos.length >= 4) break;
        const file = files[i];
        if (!file.type.startsWith('image/')) continue;
        newPhotos.push({ file, url: URL.createObjectURL(file), lat: null, lng: null });
      }
      
      Store.set('complaintDraft', { ...draft, photos: newPhotos });
      _renderPhotoGrid();
    });

    // Videos
    [1, 2].forEach(num => {
      const zone = document.getElementById(`videoZone${num}`);
      const inp  = document.getElementById(`videoInput${num}`);
      zone?.addEventListener('click', () => inp?.click());
      inp?.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        if (file.size > 50 * 1024 * 1024) { toast('Video too large (Max 50MB)', 'error'); return; }
        
        const draft = Store.get('complaintDraft');
        const videos = draft.videos || [null, null];
        videos[num - 1] = file;
        Store.set('complaintDraft', { ...draft, videos });
        
        zone.innerHTML = `<div class="upload-icon text-green">✅</div><p>${file.name.slice(0,15)}...</p>`;
      });
    });
  }

  function _renderPhotoGrid() {
    const draft = Store.get('complaintDraft');
    const grid  = document.getElementById('photoPreviewGrid');
    if (!grid) return;
    grid.innerHTML = (draft.photos || []).map((p, i) => `
      <div class="photo-preview-item">
        <img src="${p.url}" />
        <span class="photo-gps-badge">${p.lat ? '📍 GPS Attached' : '⚠️ No GPS'}</span>
        <button class="btn-remove-photo" onclick="Citizen.removePhoto(${i})">✕</button>
      </div>
    `).join('');
  }

  function removePhoto(idx) {
    const draft = Store.get('complaintDraft');
    const photos = [...(draft.photos || [])];
    photos.splice(idx, 1);
    Store.set('complaintDraft', { ...draft, photos });
    _renderPhotoGrid();
  }

  function _initComplaintForm() {
    AiPanel.attach('complaintText');

    document.getElementById('btnStep1Next')?.addEventListener('click', () => {
      const text = document.getElementById('complaintText')?.value.trim();
      if (!text || text.length < 15) { toast('Please describe your issue in at least 15 characters', 'warn'); return; }
      const draft = Store.get('complaintDraft') || {};
      Store.set('complaintDraft', { ...draft, description: text });
      AiPanel.analyze(text);
      _showStep(2);
      setTimeout(_initMap, 200);
    });

    document.getElementById('btnGetLocation')?.addEventListener('click', () => {
      if (!navigator.geolocation) { toast('Geolocation not supported', 'warn'); return; }
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          if (_map) _map.setView([pos.coords.latitude, pos.coords.longitude], 14);
          _setMapPin(pos.coords.latitude, pos.coords.longitude);
        },
        () => toast('Could not get location', 'warn')
      );
    });

    document.getElementById('btnStep2Back')?.addEventListener('click', () => _showStep(1));
    document.getElementById('btnStep2Next')?.addEventListener('click', () => {
      const locality = document.getElementById('localityInput')?.value.trim();
      Store.set('complaintDraft', { ...Store.get('complaintDraft'), locality });
      _showStep(3);
    });

    _initEvidence();

    document.getElementById('btnStep3Back')?.addEventListener('click', () => _showStep(2));
    document.getElementById('btnStep3Next')?.addEventListener('click', () => {
      _buildReview();
      _showStep(4);
    });

    document.getElementById('btnStep4Back')?.addEventListener('click', () => _showStep(3));
    document.getElementById('btnSubmitComplaint')?.addEventListener('click', _submitComplaint);
  }

  // ── Complaints List & Modals ─────────────────────────────────────────────
  async function loadMyComplaints(filterStatus = null) {
    const container = document.getElementById('citizenComplaintsList');
    if (!container) return;
    container.innerHTML = '<div class="loading-text">Loading...</div>';

    try {
      const res = await Api.complaints.mine(filterStatus);
      let complaints = res.complaints;
      Store.set('myComplaints', complaints);

      if (filterStatus) complaints = complaints.filter(c => c.status === filterStatus);

      if (!complaints.length) {
        container.innerHTML = '<p class="text-gray mt-16">No complaints found.</p>';
        return;
      }

      container.innerHTML = complaints.map(c => `
        <div class="complaint-card card-glass">
          <div class="cc-header"><span class="cc-id font-mono">${c.id}</span>${STATUS_BADGE[c.status] || c.status}</div>
          <p class="cc-desc">${c.description?.slice(0, 100)}...</p>
          <div class="cc-meta">🏷️ ${c.category} ${PRIORITY_BADGE[c.priority] || ''} 📅 ${_fmtDate(c.created_at)}</div>
          <button class="btn btn-ghost btn-sm mt-8 cc-track" data-cid="${c.id}">🔍 View Details</button>
        </div>
      `).join('');

      container.querySelectorAll('.cc-track').forEach(btn => {
        btn.addEventListener('click', () => _showComplaintDetail(btn.dataset.cid));
      });
    } catch (err) {
      container.innerHTML = `<div class="error-state">Failed to load: ${err.message}</div>`;
    }
  }

  function _showComplaintDetail(cid) {
    const c = Store.get('myComplaints').find(x => x.id === cid);
    if (!c) return;

    const modal = document.getElementById('complaintModal');
    const body  = document.getElementById('modalBody');
    document.getElementById('modalTitle').textContent = `Complaint ${c.id}`;

    let denialHtml = '';
    if (c.status === 'denied' && c.denial_reason) {
      denialHtml = `<div class="alert-error mt-8 p-8 rounded-md bg-red-900 text-white"><strong>Denial Reason:</strong> ${c.denial_reason}</div>`;
    }

    body.innerHTML = `
      <div class="modal-detail">
        <div class="md-row"><span class="md-label">Status</span>${STATUS_BADGE[c.status]}</div>
        ${denialHtml}
        <div class="md-row"><span class="md-label">Category</span><span>${c.category}</span></div>
        <div class="md-row full"><span class="md-label">Description</span><p class="md-desc">${c.description}</p></div>
        
        <div class="evidence-display mt-16">
          ${(c.photos || []).map(p => `<img src="${p.url.startsWith('http') ? p.url : `${API_BASE}${p.url}`}" class="evidence-img-small" />`).join('')}
          ${(c.videos || []).map(v => `<video src="${v.url.startsWith('http') ? v.url : `${API_BASE}${v.url}`}" class="evidence-vid-small" controls></video>`).join('')}
        </div>
        
        <div class="md-timeline mt-16">
          <h4>Status Timeline</h4>
          ${(c.history || []).map(h => `
            <div class="timeline-item"><span class="tl-dot"></span>
              <div class="tl-content"><span class="tl-status">${h.status}</span>
                <span class="tl-note">${h.note || ''}</span>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
    modal.classList.remove('hidden');
  }

  // ── Track Complaint ───────────────────────────────────────────────────────
  function _initTrackSection() {
    const btnTrack = document.getElementById('btnTrack');
    const trackId  = document.getElementById('trackId');
    const result   = document.getElementById('trackResult');

    btnTrack?.addEventListener('click', async () => {
      const cid = trackId?.value.trim();
      if (!cid) { toast('Enter a Complaint ID', 'warn'); return; }

      btnTrack.disabled = true;
      btnTrack.innerHTML = '⏳ Tracking...';

      try {
        const c = await Api.complaints.track(cid);
        result.classList.remove('hidden');
        result.innerHTML = `
          <div class="card-glass track-card mt-16 animate-fade-in">
            <div class="track-header">
              <h3>Complaint ${c.id}</h3>
              ${STATUS_BADGE[c.status] || c.status}
            </div>
            <div class="track-body mt-16">
              <div class="md-row"><span class="md-label">Category</span><span>${c.category || '—'}</span></div>
              <div class="md-row"><span class="md-label">Priority</span>${PRIORITY_BADGE[c.priority] || ''}</div>
              <div class="md-row"><span class="md-label">Location</span><span>${c.locality ? c.locality : (c.latitude && c.longitude ? c.latitude.toFixed(4) + ', ' + c.longitude.toFixed(4) : '—')}</span></div>
              <p class="mt-16 text-gray">${c.description}</p>
              
              <div class="evidence-display mt-16">
                ${(c.photos || []).map(p => `<img src="${p.url.startsWith('http') ? p.url : `${API_BASE}${p.url}`}" class="evidence-img-small" />`).join('')}
                ${(c.videos || []).map(v => `<video src="${v.url.startsWith('http') ? v.url : `${API_BASE}${v.url}`}" class="evidence-vid-small" controls></video>`).join('')}
              </div>
              
              <div class="track-timeline mt-24">
                <h4>Status History</h4>
                ${(c.history || []).map(h => `
                  <div class="timeline-item"><span class="tl-dot"></span>
                    <div class="tl-content"><span class="tl-status">${h.status}</span>
                      <span class="tl-note">${h.note || ''}</span>
                      <span class="tl-who">${_fmtDate(h.changed_at)}</span>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>
        `;
      } catch (err) {
        toast('Complaint not found or error: ' + err.message, 'error');
        result.classList.add('hidden');
      } finally {
        btnTrack.disabled = false;
        btnTrack.innerHTML = '🔍 Track';
      }
    });
  }

  // ── Notices ─────────────────────────────────────────────────────────────
  async function loadNotices() {
    const container = document.getElementById('citizenNoticesList');
    if (!container) return;
    
    try {
      const res = await Api.notices.list('Ward 42', null);
      const notices = res.notices;
      
      if (!notices.length) {
        container.innerHTML = '<p class="text-gray mt-16">No active notices for your area.</p>';
        return;
      }

      container.innerHTML = notices.map(n => `
        <div class="notice-card card-glass severity-${n.severity}">
          <div class="nc-header">
            <h4>${n.title}</h4>
            <span class="text-sm text-gray">${_fmtDate(n.created_at)}</span>
          </div>
          <p class="nc-message mt-8">${n.message}</p>
          ${n.ward_tag ? `<span class="badge badge-outline mt-8">📍 ${n.ward_tag}</span>` : ''}
          <div class="evidence-display mt-8">
            ${n.photo_url ? `
              <a href="${n.photo_url.startsWith('http') ? n.photo_url : `${API_BASE}${n.photo_url}`}" target="_blank" title="View Full Photo">
                <img src="${n.photo_url.startsWith('http') ? n.photo_url : `${API_BASE}${n.photo_url}`}" class="evidence-img-small" />
              </a>` : ''}
            ${n.video_url ? `
              <a href="${n.video_url.startsWith('http') ? n.video_url : `${API_BASE}${n.video_url}`}" target="_blank" title="Play Full Video">
                <video src="${n.video_url.startsWith('http') ? n.video_url : `${API_BASE}${n.video_url}`}" class="evidence-vid-small"></video>
              </a>` : ''}
          </div>
        </div>
      `).join('');

      // Update badge
      const badge = document.getElementById('noticeBadge');
      if (badge && notices.length > 0) {
        badge.style.display = 'inline-block';
      }
    } catch (e) {
      container.innerHTML = '<p class="text-red">Failed to load notices.</p>';
    }
  }

  function init() {
    _initComplaintForm();
    _initTrackSection();
    
    document.querySelectorAll('.filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        loadMyComplaints(btn.dataset.filter === 'all' ? null : btn.dataset.filter);
      });
    });

    Router.registerSectionCallback('history', () => loadMyComplaints());
    Router.registerSectionCallback('track',   () => {
      const result = document.getElementById('trackResult');
      if (result) result.classList.add('hidden');
      const trackId = document.getElementById('trackId');
      if (trackId) trackId.value = '';
    });
    Router.registerSectionCallback('notices', () => loadNotices());
  }

  return { init, removePhoto, loadMyComplaints, loadNotices };
})();
