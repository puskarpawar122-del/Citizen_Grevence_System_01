/**
 * store.js — Global application state
 * Single source of truth for the SPA.
 */

const Store = (() => {
  const _state = {
    // Auth
    role: null,               // 'citizen' | 'admin' | null
    citizenToken: null,       // The NYV-YEAR-... token string
    accessToken: null,        // JWT for API calls
    adminInfo: null,          // { username, full_name, ... }

    // Navigation
    currentPage: 'landing',
    currentSection: null,

    // Complaint form state
    complaintDraft: {
      description: '',
      latitude: null,
      longitude: null,
      locality: '',
      imageFile: null,
      aiAnalysis: null,
    },

    // Citizen data
    myComplaints: [],

    // Admin data
    allComplaints: [],
    kpiStats: { total: 0, pending: 0, resolved: 0, critical: 0 },
    analyticsData: null,
    feedbackList: [],
  };

  // Persist auth to sessionStorage
  function _save() {
    try {
      sessionStorage.setItem('nyv_role',   _state.role || '');
      sessionStorage.setItem('nyv_ct',     _state.citizenToken || '');
      sessionStorage.setItem('nyv_jwt',    _state.accessToken || '');
      sessionStorage.setItem('nyv_admin',  JSON.stringify(_state.adminInfo || null));
    } catch (_) {}
  }

  function _load() {
    try {
      _state.role         = sessionStorage.getItem('nyv_role') || null;
      _state.citizenToken = sessionStorage.getItem('nyv_ct')   || null;
      _state.accessToken  = sessionStorage.getItem('nyv_jwt')  || null;
      const adminRaw      = sessionStorage.getItem('nyv_admin');
      _state.adminInfo    = adminRaw ? JSON.parse(adminRaw) : null;
    } catch (_) {}
  }

  function setAuth({ role, citizenToken, accessToken, adminInfo }) {
    _state.role         = role;
    _state.citizenToken = citizenToken || null;
    _state.accessToken  = accessToken  || null;
    _state.adminInfo    = adminInfo    || null;
    _save();
  }

  function clearAuth() {
    _state.role = _state.citizenToken = _state.accessToken = _state.adminInfo = null;
    sessionStorage.clear();
  }

  function get(key) { return _state[key]; }
  function set(key, val) { _state[key] = val; }

  // Initialize from storage
  _load();

  return { get, set, setAuth, clearAuth };
})();
