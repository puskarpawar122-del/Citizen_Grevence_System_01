/**
 * api.js — All API calls to the FastAPI backend.
 * Reads the JWT from Store and injects it automatically.
 * Auto-detects backend availability and falls back to demo mode gracefully.
 */

const API_BASE = '';
let _backendAvailable = true;

const Api = (() => {
  async function _request(method, path, body = null, isForm = false) {
    const headers = {};
    const jwt = Store.get('accessToken');
    if (jwt) headers['Authorization'] = `Bearer ${jwt}`;

    let fetchBody = null;
    if (body) {
      if (isForm) {
        fetchBody = body; // FormData
      } else {
        headers['Content-Type'] = 'application/json';
        fetchBody = JSON.stringify(body);
      }
    }

    const res  = await fetch(`${API_BASE}${path}`, { method, headers, body: fetchBody });
    const data = await res.json().catch(() => ({ detail: 'Unknown error' }));
    if (!res.ok) {
      let msg = data.detail;
      if (Array.isArray(data.detail)) {
        msg = data.detail.map(d => `${d.loc ? d.loc[d.loc.length-1] : 'field'}: ${d.msg}`).join(', ');
      }
      throw new Error(msg || `HTTP ${res.status}`);
    }
    return data;
  }

  // ── Auth ──────────────────────────────────────────────────────────────
  const auth = {
    // OTP-based citizen login
    sendOtp:    (phone)        => _request('POST', '/api/auth/otp/send',   { phone }),
    verifyOtp:  (phone, code)  => _request('POST', '/api/auth/otp/verify', { phone, code }),
    // Admin login (unchanged)
    adminLogin: (u, p)         => _request('POST', '/api/auth/admin/login', { username: u, password: p }),
  };

  // ── Complaints ─────────────────────────────────────────────────────────
  const complaints = {
    submit:  (formData)           => _request('POST', '/api/complaints/submit', formData, true),
    mine:    (status)             => _request('GET',  `/api/complaints/mine${status ? `?status=${status}` : ''}`),
    track:   (id)                 => _request('GET',  `/api/complaints/track/${id}`),

    // Admin
    all: (filters = {}) => {
      const q = new URLSearchParams(filters).toString();
      return _request('GET', `/api/complaints/admin/all${q ? '?' + q : ''}`);
    },
    kpi:          ()             => _request('GET',   '/api/complaints/admin/kpi'),
    updateStatus: (id, s, note)  => _request('PATCH', `/api/complaints/admin/${id}/status`, { status: s, note }),
    approve:      (id)           => _request('POST',  `/api/complaints/admin/${id}/approve`),
    deny:         (id, reason)   => _request('POST',  `/api/complaints/admin/${id}/deny`, { reason }),
  };

  // ── AI ────────────────────────────────────────────────────────────────
  const ai = {
    analyze:   (text)  => _request('POST', '/api/ai/analyze', { text }),
    analytics: ()      => _request('GET',  '/api/ai/analytics'),
    aiStats:   ()      => _request('GET',  '/api/ai/stats'),
    feedback:  (body)  => _request('POST', '/api/ai/feedback', body),
  };

  // ── Notices ───────────────────────────────────────────────────────────
  const notices = {
    list:       (ward, zone)  => {
      const q = new URLSearchParams();
      if (ward) q.set('ward', ward);
      if (zone) q.set('zone', zone);
      return _request('GET', `/api/notices/${q.toString() ? '?' + q : ''}`);
    },
    create:     (formData)    => _request('POST',  '/api/notices/admin/create',           formData, true),
    listAdmin:  ()            => _request('GET',   '/api/notices/admin/all'),
    deactivate: (id)          => _request('PATCH', `/api/notices/admin/${id}/deactivate`),
  };

  const demo = {
    isDemo: () => false,
    getComplaints: () => [],
    getNotices: () => [],
    analyze: () => ({}),
    kpi: () => ({ total: 0, pending: 0, resolved: 0, critical: 0 })
  };

  return { auth, complaints, ai, notices, demo };
})();
