/**
 * admin.js — Admin Dashboard
 * Overview KPIs, all complaints table, Chart.js analytics,
 * AI feedback loop, and routing map.
 */

const Admin = (() => {

  // ── Helpers ──────────────────────────────────────────────────────────────

  function toast(msg, type = 'info') {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = msg;
    el.className   = `toast toast-${type}`;
    el.classList.remove('hidden');
    setTimeout(() => el.classList.add('hidden'), 3500);
  }

  function _fmtDate(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
  }

  const PRIORITY_BADGE = {
    CRITICAL: '<span class="badge badge-critical">🔴 CRITICAL</span>',
    HIGH:     '<span class="badge badge-high">🟠 HIGH</span>',
    MEDIUM:   '<span class="badge badge-medium">🔵 MEDIUM</span>',
    LOW:      '<span class="badge badge-low">🟢 LOW</span>',
  };

  const STATUS_BADGE = {
    pending:     '<span class="status-badge status-pending">⏳ Pending</span>',
    in_progress: '<span class="status-badge status-progress">🔄 In Progress</span>',
    resolved:    '<span class="status-badge status-resolved">✅ Resolved</span>',
    escalated:   '<span class="status-badge status-escalated">🚨 Escalated</span>',
    denied:      '<span class="status-badge status-denied">🚫 Denied</span>',
  };

  // ── Chart instances (to avoid re-creating) ───────────────────────────────

  const _charts = {};

  function _destroyChart(id) {
    if (_charts[id]) { _charts[id].destroy(); delete _charts[id]; }
  }

  // ── Demo data generators ─────────────────────────────────────────────────

  function _demoAnalytics() {
    return {
      category: [
        { label:'Water Supply', count:34 },
        { label:'Roads',        count:28 },
        { label:'Electricity',  count:21 },
        { label:'Sanitation',   count:17 },
        { label:'Healthcare',   count:12 },
        { label:'Other',        count:8  },
      ],
      priority: [
        { label:'CRITICAL', count:15 },
        { label:'HIGH',     count:38 },
        { label:'MEDIUM',   count:52 },
        { label:'LOW',      count:15 },
      ],
      language: [
        { label:'hinglish', count:40 },
        { label:'hi',       count:30 },
        { label:'en',       count:25 },
        { label:'mr',       count:15 },
        { label:'te',       count:8  },
        { label:'ta',       count:5  },
        { label:'bn',       count:3  },
      ],
      department: [
        { dept:'Municipal Water Supply Department', total:34, resolved:22 },
        { dept:'Public Works Department (PWD)',     total:28, resolved:18 },
        { dept:'State Electricity Board',           total:21, resolved:15 },
        { dept:'Sanitation & Waste Management Dept.', total:17, resolved:9 },
        { dept:'District Health Office',            total:12, resolved:6  },
      ],
      timeline: [
        { week:'Week 1', count:12 },
        { week:'Week 2', count:18 },
        { week:'Week 3', count:24 },
        { week:'Week 4', count:20 },
        { week:'Week 5', count:31 },
        { week:'Week 6', count:27 },
        { week:'Week 7', count:35 },
      ],
    };
  }

  // ── Overview Section ──────────────────────────────────────────────────────

  async function initOverview() {
    // Set date
    const dateEl = document.getElementById('overviewDate');
    if (dateEl) dateEl.textContent = new Date().toLocaleDateString('en-IN', { weekday:'long', year:'numeric', month:'long', day:'numeric' });

    // KPIs
    try {
      const kpi = await Api.complaints.kpi();
      Store.set('kpiStats', kpi);
      document.getElementById('kpiTotal')?.setAttribute('data-target', kpi.total);
      document.getElementById('kpiPending')?.setAttribute('data-target', kpi.pending);
      document.getElementById('kpiResolved')?.setAttribute('data-target', kpi.resolved);
      document.getElementById('kpiCritical')?.setAttribute('data-target', kpi.critical);
      _animateKPIs();
    } catch (_) {}

    // Recent complaints table
    await _loadRecentTable();
  }

  function _animateKPIs() {
    document.querySelectorAll('.kpi-value').forEach(el => {
      const target = parseInt(el.getAttribute('data-target') || el.textContent, 10);
      if (isNaN(target)) return;
      let current = 0;
      const step = Math.ceil(target / 40);
      const timer = setInterval(() => {
        current = Math.min(current + step, target);
        el.textContent = current;
        if (current >= target) clearInterval(timer);
      }, 30);
    });
  }

  async function _loadRecentTable() {
    const tbody = document.getElementById('recentTableBody');
    if (!tbody) return;

    let complaints = [];
    try {
      const res = await Api.complaints.all({ limit: 5 });
      complaints = res.complaints;
    } catch (err) {
      console.error(err);
    }

    tbody.innerHTML = complaints.map(c => `
      <tr>
        <td class="font-mono">${c.id}</td>
        <td>${c.category || '—'}</td>
        <td>${c.language || c.detected_lang || '—'}</td>
        <td>${PRIORITY_BADGE[c.priority] || c.priority}</td>
        <td>${STATUS_BADGE[c.status] || c.status}</td>
        <td>${c.locality ? c.locality : (c.latitude && c.longitude ? c.latitude.toFixed(4) + ', ' + c.longitude.toFixed(4) : '—')}</td>
        <td>
          <button class="btn btn-ghost btn-xs" data-cid="${c.id}">View</button>
          <select class="form-select select-inline" data-cid="${c.id}" data-select-status>
            <option value="">Update Status</option>
            <option value="in_progress">In Progress</option>
            <option value="resolved">Resolved</option>
            <option value="escalated">Escalated</option>
          </select>
        </td>
      </tr>
    `).join('');

    _attachTableActions(tbody, complaints);
  }

  // ── All Complaints Section ────────────────────────────────────────────────

  async function initAllComplaints() {
    await _loadAllTable();

    ['filterStatus','filterCategory','filterPriority'].forEach(id => {
      document.getElementById(id)?.addEventListener('change', _loadAllTable);
    });
  }

  async function _loadAllTable() {
    const tbody = document.getElementById('allComplaintsBody');
    if (!tbody) return;

    const status   = document.getElementById('filterStatus')?.value   || null;
    const category = document.getElementById('filterCategory')?.value || null;
    const priority = document.getElementById('filterPriority')?.value || null;

    tbody.innerHTML = '<tr><td colspan="9" class="loading-text">Loading...</td></tr>';

    let complaints = [];
    try {
      const filters = {};
      if (status)   filters.status   = status;
      if (category) filters.category = category;
      if (priority) filters.priority = priority;
      const res = await Api.complaints.all(filters);
      complaints = res.complaints;
    } catch (err) {
      console.error(err);
    }

    Store.set('allComplaints', complaints);

    if (!complaints.length) {
      tbody.innerHTML = '<tr><td colspan="9" class="empty-cell">No complaints found.</td></tr>';
      return;
    }

    tbody.innerHTML = complaints.map(c => `
      <tr>
        <td class="font-mono">${c.id}</td>
        <td title="${c.description}">${c.description?.slice(0, 45)}...</td>
        <td>${c.language || c.detected_lang || '—'}</td>
        <td>${c.category || '—'}</td>
        <td>${PRIORITY_BADGE[c.priority] || c.priority}</td>
        <td>${STATUS_BADGE[c.status] || c.status}</td>
        <td>${c.department?.split('(')[0]?.trim() || '—'}</td>
        <td>${_fmtDate(c.created_at)}</td>
        <td>
          <button class="btn btn-ghost btn-xs" data-cid="${c.id}">View</button>
          <select class="form-select select-inline" data-cid="${c.id}" data-select-status>
            <option value="">Status</option>
            <option value="in_progress">In Progress</option>
            <option value="resolved">Resolved</option>
            <option value="escalated">Escalated</option>
          </select>
        </td>
      </tr>
    `).join('');

    _attachTableActions(tbody, complaints);
  }

  function _attachTableActions(tbody, complaints) {
    // View buttons
    tbody.querySelectorAll('button[data-cid]').forEach(btn => {
      btn.addEventListener('click', () => _showAdminModal(btn.dataset.cid, complaints));
    });

    // Status selects
    tbody.querySelectorAll('select[data-select-status]').forEach(sel => {
      sel.addEventListener('change', async () => {
        const newStatus = sel.value;
        const cid       = sel.dataset.cid;
        if (!newStatus) return;
        await _updateStatus(cid, newStatus);
        sel.value = '';
      });
    });
  }

  async function _updateStatus(cid, status) {
    try {
      await Api.complaints.updateStatus(cid, status);
      toast(`✅ Status updated to "${status}"`, 'success');
      await _loadAllTable();
    } catch (err) {
      toast('Update failed: ' + err.message, 'error');
    }
  }

  function _showAdminModal(cid, complaints) {
    const c = complaints.find(x => x.id === cid);
    if (!c) return;

    const modal = document.getElementById('complaintModal');
    const body  = document.getElementById('modalBody');
    const title = document.getElementById('modalTitle');
    if (!modal || !body) return;
    if (title) title.textContent = `Admin — Complaint ${c.id}`;

    // Build Evidence HTML
    let evidenceHtml = '';
    if (c.photos && c.photos.length > 0) {
      evidenceHtml += `<h4>📷 Photos (${c.photos.length})</h4><div class="evidence-grid">`;
      c.photos.forEach(p => {
        const fullUrl = p.url.startsWith('http') ? p.url : `${API_BASE}${p.url}`;
        evidenceHtml += `<div class="evidence-item">
          <img src="${fullUrl}" class="modal-evidence-img" />
          <div class="mt-4 text-xs text-gray">📍 GPS: ${p.lat}, ${p.lng}</div>
          <a href="${fullUrl}" download class="btn btn-outline btn-xs mt-4">⬇️ Download Image</a>
        </div>`;
      });
      evidenceHtml += `</div>`;
    }
    if (c.videos && c.videos.length > 0) {
      evidenceHtml += `<h4 class="mt-16">🎥 Videos (${c.videos.length})</h4><div class="evidence-grid">`;
      c.videos.forEach((v, i) => {
        const fullUrl = v.url.startsWith('http') ? v.url : `${API_BASE}${v.url}`;
        evidenceHtml += `<div class="evidence-item">
          <video src="${fullUrl}" controls class="modal-evidence-video"></video>
          <a href="${fullUrl}" download class="btn btn-outline btn-xs mt-4">⬇️ Download Video ${i+1}</a>
        </div>`;
      });
      evidenceHtml += `</div>`;
    }

    body.innerHTML = `
      <div class="modal-detail">
        <div class="md-row"><span class="md-label">Status</span>${STATUS_BADGE[c.status]||c.status}</div>
        <div class="md-row"><span class="md-label">Category</span><span>${c.category||'—'}</span></div>
        <div class="md-row"><span class="md-label">Priority</span>${PRIORITY_BADGE[c.priority]||''}</div>
        <div class="md-row"><span class="md-label">Department</span><span>${c.department||'—'}</span></div>
        <div class="md-row"><span class="md-label">Location</span><span>${c.locality ? c.locality : (c.latitude && c.longitude ? c.latitude.toFixed(4) + ', ' + c.longitude.toFixed(4) : '—')}</span></div>
        <div class="md-row full"><span class="md-label">Description</span><p class="md-desc">${c.description}</p></div>
        
        <div class="md-row full evidence-container">${evidenceHtml}</div>

        <div class="md-admin-actions">
          <h4>🛠️ Admin Actions</h4>
          ${c.status === 'pending' ? `
            <div class="btn-row">
              <button class="btn btn-primary btn-sm" id="btnApprove" data-cid="${c.id}">✅ Approve Complaint</button>
            </div>
            <div class="form-group mt-16">
              <label class="form-label text-red">Denial Reason (Required for Denial)</label>
              <textarea id="denyReason" class="form-input form-textarea" rows="2" placeholder="Explain why this is denied..."></textarea>
              <button class="btn btn-danger btn-sm mt-8" id="btnDeny" data-cid="${c.id}">❌ Deny Complaint</button>
            </div>
          ` : `
            <div class="btn-row">
              <button class="btn btn-outline btn-sm" data-update="resolved" data-cid="${c.id}">✅ Mark Resolved</button>
              <button class="btn btn-danger btn-sm" data-update="escalated" data-cid="${c.id}">🚨 Escalate</button>
            </div>
          `}
        </div>
        <div class="md-timeline mt-24">
          <h4>Status Timeline</h4>
          ${(c.history||[]).map(h=>`
            <div class="timeline-item"><span class="tl-dot"></span>
              <div class="tl-content"><span class="tl-status">${h.status}</span>
                <span class="tl-note">${h.note||''}</span>
                <span class="tl-who">by ${h.changed_by} · ${_fmtDate(h.changed_at)}</span>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;

    // Action handlers
    body.querySelectorAll('button[data-update]').forEach(btn => {
      btn.addEventListener('click', async () => {
        await _updateStatus(btn.dataset.cid, btn.dataset.update);
        modal.classList.add('hidden');
      });
    });

    document.getElementById('btnApprove')?.addEventListener('click', async (e) => {
      try {
        await Api.complaints.approve(e.target.dataset.cid);
        toast('✅ Complaint Approved!', 'success');
        await _loadAllTable();
        modal.classList.add('hidden');
      } catch (err) { toast(err.message, 'error'); }
    });

    document.getElementById('btnDeny')?.addEventListener('click', async (e) => {
      const reason = document.getElementById('denyReason').value.trim();
      if (!reason) { toast('Please enter a denial reason.', 'warn'); return; }
      try {
        await Api.complaints.deny(e.target.dataset.cid, reason);
        toast('🚫 Complaint Denied', 'success');
        await _loadAllTable();
        modal.classList.add('hidden');
      } catch (err) { toast(err.message, 'error'); }
    });

    modal.classList.remove('hidden');
  }

  // ── Analytics Section ────────────────────────────────────────────────────

  async function initAnalytics() {
    let data;
    try {
      data = await Api.ai.analytics();
    } catch (_) {
      data = _demoAnalytics();
    }

    Store.set('analyticsData', data);
    _renderCharts(data);
  }

  const PALETTE = ['#9b6dc8','#b48dd4','#7bbfbf','#3a8f6f','#c07a1a','#c0392b','#d4a0e0'];

  function _renderCharts(data) {
    // Category
    _destroyChart('chartCategory');
    _charts['chartCategory'] = new Chart(document.getElementById('chartCategory'), {
      type: 'doughnut',
      data: {
        labels:   data.category.map(d => d.label),
        datasets: [{ data: data.category.map(d => d.count), backgroundColor: PALETTE, borderWidth: 0 }],
      },
      options: { plugins: { legend: { position:'bottom', labels:{ color:'#5a4f46' } } }, cutout:'65%' },
    });

    // Priority
    _destroyChart('chartPriority');
    const priColors = { CRITICAL:'#c0392b', HIGH:'#c07a1a', MEDIUM:'#9b6dc8', LOW:'#3a8f6f' };
    _charts['chartPriority'] = new Chart(document.getElementById('chartPriority'), {
      type: 'bar',
      data: {
        labels:   data.priority.map(d => d.label),
        datasets: [{ data: data.priority.map(d => d.count), backgroundColor: data.priority.map(d => priColors[d.label]||'#9e8e82'), borderRadius: 6, borderSkipped: false }],
      },
      options: { plugins:{ legend:{display:false} }, scales:{ x:{ ticks:{color:'#5a4f46'}, grid:{color:'rgba(120,100,80,0.08)'} }, y:{ ticks:{color:'#5a4f46'}, grid:{color:'rgba(120,100,80,0.08)'} } } },
    });

    // Timeline
    _destroyChart('chartTimeline');
    _charts['chartTimeline'] = new Chart(document.getElementById('chartTimeline'), {
      type: 'line',
      data: {
        labels:   data.timeline.map(d => d.week),
        datasets: [{
          label:'Complaints',
          data: data.timeline.map(d => d.count),
          borderColor:'#9b6dc8', backgroundColor:'rgba(155,109,200,0.12)',
          fill:true, tension:0.4, pointBackgroundColor:'#9b6dc8', pointRadius:4,
        }],
      },
      options: { plugins:{legend:{labels:{color:'#5a4f46'}}}, scales:{ x:{ticks:{color:'#5a4f46'},grid:{color:'rgba(120,100,80,0.08)'}}, y:{ticks:{color:'#5a4f46'},grid:{color:'rgba(120,100,80,0.08)'}} } },
    });

    // Language
    _destroyChart('chartLanguage');
    const langLabels = { en:'English', hi:'Hindi', hinglish:'Hinglish', mr:'Marathi', te:'Telugu', ta:'Tamil', bn:'Bengali' };
    _charts['chartLanguage'] = new Chart(document.getElementById('chartLanguage'), {
      type: 'polarArea',
      data: {
        labels:   data.language.map(d => langLabels[d.label] || d.label),
        datasets: [{ data: data.language.map(d => d.count), backgroundColor: PALETTE.map(c => c + 'bb') }],
      },
      options: { plugins:{ legend:{ position:'bottom', labels:{color:'#5a4f46'} } }, scales:{ r:{ grid:{color:'rgba(120,100,80,0.10)'}, ticks:{display:false} } } },
    });

    // Department resolution
    _destroyChart('chartDept');
    _charts['chartDept'] = new Chart(document.getElementById('chartDept'), {
      type: 'bar',
      data: {
        labels: data.department.map(d => d.dept.split('(')[0].trim().replace(' Department','').replace(' Dept.','').trim()),
        datasets: [
          { label:'Total',    data:data.department.map(d=>d.total),    backgroundColor:'rgba(155,109,200,0.65)', borderRadius:4 },
          { label:'Resolved', data:data.department.map(d=>d.resolved), backgroundColor:'rgba(58,143,111,0.75)', borderRadius:4 },
        ],
      },
      options: { plugins:{ legend:{ labels:{color:'#5a4f46'} } }, scales:{ x:{ticks:{color:'#5a4f46'},grid:{color:'rgba(120,100,80,0.08)'}}, y:{ticks:{color:'#5a4f46'},grid:{color:'rgba(120,100,80,0.08)'}} } },
    });
  }

  // ── AI Feedback Loop Section ──────────────────────────────────────────────

  async function initAiFeedback() {
    // Stats
    try {
      const stats = await Api.ai.aiStats();
      document.getElementById('fbTotal')?.setAttribute('data-target', stats.corrections || 0);
      document.getElementById('fbAccuracy').textContent = `${stats.accuracy}%`;
      document.getElementById('fbLastTrained').textContent = 'Yesterday';
    } catch (_) {}

    // List flagged complaints
    const list = document.getElementById('feedbackList');
    if (!list) return;
    const complaints = Store.get('allComplaints') || [];
    list.innerHTML = complaints.map(c => `
      <div class="feedback-item card-glass">
        <div class="fi-header">
          <span class="font-mono">${c.id}</span>
          ${PRIORITY_BADGE[c.priority]||''}
        </div>
        <p class="fi-text">${c.description?.slice(0,80)}...</p>
        <div class="fi-actions">
          <span class="fi-ai">AI said: <strong>${c.category}</strong></span>
          <button class="btn btn-ghost btn-xs" data-cid="${c.id}">✏️ Correct</button>
        </div>
      </div>
    `).join('');
  }

  // ── Routing Map Section ───────────────────────────────────────────────────

  let _adminMap = null;

  function initRoutingMap() {
    if (_adminMap) { _adminMap.invalidateSize(); return; }
    try {
      _adminMap = L.map('adminMap').setView([20.5937, 78.9629], 5);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
      }).addTo(_adminMap);

      // Add demo pins
      const DEMO_PINS = [
        [19.076, 72.877, 'Water Supply', 'CMP-2024-00001', 'CRITICAL'],
        [28.613, 77.209, 'Roads',        'CMP-2024-00002', 'MEDIUM'],
        [12.972, 77.594, 'Electricity',  'CMP-2024-00003', 'HIGH'],
        [22.572, 88.363, 'Sanitation',   'CMP-2024-00004', 'HIGH'],
        [17.385, 78.486, 'Healthcare',   'CMP-2024-00005', 'CRITICAL'],
      ];

      const PRIORITY_COLOR = { CRITICAL:'#ef4444', HIGH:'#f59e0b', MEDIUM:'#4f8ef7', LOW:'#10b981' };

      DEMO_PINS.forEach(([lat, lng, cat, id, pri]) => {
        const circle = L.circleMarker([lat, lng], {
          radius: 10, fillColor: PRIORITY_COLOR[pri], color: '#fff',
          weight: 2, opacity: 1, fillOpacity: 0.85,
        }).addTo(_adminMap);
        circle.bindPopup(`<strong>${id}</strong><br>📍 ${cat}<br>Priority: ${pri}`);
      });
    } catch (_) {}

    // Dept routing grid
    const grid = document.getElementById('deptRoutingGrid');
    if (!grid) return;
    const depts = [
      { name:'Municipal Water Supply',    count:34, color:'#06b6d4' },
      { name:'Public Works (PWD)',         count:28, color:'#4f8ef7' },
      { name:'State Electricity Board',   count:21, color:'#f59e0b' },
      { name:'Sanitation & Waste Mgmt.',  count:17, color:'#10b981' },
      { name:'District Health Office',    count:12, color:'#ef4444' },
    ];
    grid.innerHTML = depts.map(d => `
      <div class="dept-card card-glass">
        <div class="dept-dot" style="background:${d.color}"></div>
        <div class="dept-info">
          <span class="dept-name">${d.name}</span>
          <span class="dept-count">${d.count} complaints</span>
        </div>
      </div>
    `).join('');
  }

  // ── Early Notices Dispatcher ──────────────────────────────────────────────

  async function initNoticesAdmin() {
    await _loadAdminNotices();

    document.getElementById('btnBroadcastNotice')?.addEventListener('click', async () => {
      const title    = document.getElementById('noticeTitle').value.trim();
      const message  = document.getElementById('noticeMessage').value.trim();
      const severity = document.getElementById('noticeSeverity').value;
      const area      = document.getElementById('noticeArea').value.trim();
      const fileInp   = document.getElementById('noticePhotoInput');
      const videoInp  = document.getElementById('noticeVideoInput');
      const btn       = document.getElementById('btnBroadcastNotice');

      if (!title || !message) { toast('Title and message are required', 'warn'); return; }

      btn.disabled = true;
      btn.textContent = '⏳ Broadcasting...';

      try {
        const fd = new FormData();
        fd.append('title', title);
        fd.append('message', message);
        fd.append('severity', severity);
        if (area) fd.append('ward_tag', area);
        if (fileInp.files[0]) fd.append('photo', fileInp.files[0]);
        if (videoInp.files[0]) fd.append('video', videoInp.files[0]);
        await Api.notices.create(fd);
        
        toast('✅ Notice Broadcasted Successfully!', 'success');
        
        // Reset form
        document.getElementById('noticeTitle').value = '';
        document.getElementById('noticeMessage').value = '';
        document.getElementById('noticeArea').value = '';
        if (fileInp)  fileInp.value = '';
        if (videoInp) videoInp.value = '';
        
        await _loadAdminNotices();
      } catch (e) {
        toast('Broadcast failed: ' + e.message, 'error');
      } finally {
        btn.disabled = false;
        btn.textContent = '📤 Broadcast Notice';
      }
    });
  }

  async function _loadAdminNotices() {
    const list = document.getElementById('adminNoticesList');
    if (!list) return;

    try {
      const notices = (await Api.notices.listAdmin()).notices;
      
      if (!notices.length) {
        list.innerHTML = '<p class="text-gray">No active notices.</p>';
        return;
      }

      list.innerHTML = notices.map(n => `
        <div class="notice-card card-glass severity-${n.severity} ${!n.is_active ? 'opacity-50' : ''}">
          <div class="nc-header">
            <h4>${n.title} ${!n.is_active ? '(Inactive)' : ''}</h4>
            <span class="text-sm text-gray">${_fmtDate(n.created_at)}</span>
          </div>
          <p class="nc-message mt-8">${n.message}</p>
          ${n.ward_tag ? `<span class="badge badge-outline mt-8">📍 ${n.ward_tag}</span>` : ''}
          <div class="evidence-display mt-8">
            ${n.photo_url ? `
              <a href="${n.photo_url.startsWith('http') ? n.photo_url : `${API_BASE}${n.photo_url}`}" target="_blank" title="View Full Photo">
                <img src="${n.photo_url.startsWith('http') ? n.photo_url : `${API_BASE}${n.photo_url}`}" class="evidence-img-small" />
              </a>` : ''}
            ${n.video_url ? `
              <a href="${n.video_url.startsWith('http') ? n.video_url : `${API_BASE}${n.video_url}`}" target="_blank" title="Play Full Video">
                <video src="${n.video_url.startsWith('http') ? n.video_url : `${API_BASE}${n.video_url}`}" class="evidence-vid-small"></video>
              </a>` : ''}
          </div>
          ${n.is_active ? `<button class="btn btn-danger btn-xs mt-8" onclick="Admin.deactivateNotice('${n.id}')">Deactivate</button>` : ''}
        </div>
      `).join('');
    } catch (e) {
      list.innerHTML = '<p class="text-red">Failed to load notices.</p>';
    }
  }

  async function deactivateNotice(id) {
    if (!confirm('Are you sure you want to deactivate this notice?')) return;
    try {
      await Api.notices.deactivate(id);
      toast('Notice deactivated', 'success');
      _loadAdminNotices();
    } catch (e) { toast('Error: ' + e.message, 'error'); }
  }

  // ── Main init ─────────────────────────────────────────────────────────────

  function init() {
    const info = Store.get('adminInfo');
    const nameEl = document.getElementById('adminName');
    if (nameEl && info) nameEl.textContent = info.full_name || info.username || 'Admin';

    initOverview();

    // Register section callbacks
    Router.registerSectionCallback('all-complaints', initAllComplaints);
    Router.registerSectionCallback('analytics',      initAnalytics);
    Router.registerSectionCallback('ai-feedback',    initAiFeedback);
    Router.registerSectionCallback('routing',        initRoutingMap);
    Router.registerSectionCallback('notices-admin',  initNoticesAdmin);

    // Admin logout
    document.getElementById('btnAdminLogout')?.addEventListener('click', () => {
      Store.clearAuth();
      Router.navigate('landing');
    });

    // Modal close
    document.getElementById('btnModalClose')?.addEventListener('click', () => {
      document.getElementById('complaintModal')?.classList.add('hidden');
    });
    document.getElementById('complaintModal')?.addEventListener('click', (e) => {
      if (e.target.id === 'complaintModal') {
        document.getElementById('complaintModal').classList.add('hidden');
      }
    });
  }

  return { init, deactivateNotice };
})();
