/**
 * app.js — Application Entry Point
 * Bootstraps the SPA: registers all page init callbacks, then starts the router.
 */

(function () {
  'use strict';

  // ── Mobile Drawer Helpers (set up early, before Router.init) ─────────────
  const mobileDrawer  = document.getElementById('mobileDrawer');
  const drawerOverlay = document.getElementById('mobileDrawerOverlay');
  const drawerClose   = document.getElementById('mobileDrawerClose');
  const mobileBottomNav = document.getElementById('mobileBottomNav');

  function openDrawer() {
    mobileDrawer?.classList.remove('hidden');
    drawerOverlay?.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }
  function closeDrawer() {
    mobileDrawer?.classList.add('hidden');
    drawerOverlay?.classList.add('hidden');
    document.body.style.overflow = '';
  }
  function showBottomNav(show) {
    if (!mobileBottomNav) return;
    mobileBottomNav.classList.toggle('hidden', !show);
  }

  // Hamburger → open drawer (overrides router.js navLinks toggle on mobile)
  document.getElementById('hamburger')?.addEventListener('click', openDrawer);
  drawerClose?.addEventListener('click', closeDrawer);
  drawerOverlay?.addEventListener('click', closeDrawer);
  mobileDrawer?.querySelectorAll('[data-page]').forEach(el =>
    el.addEventListener('click', closeDrawer)
  );

  // Bottom nav logout
  document.getElementById('mbn-logout')?.addEventListener('click', (e) => {
    e.preventDefault();
    Store.clearAuth();
    showBottomNav(false);
    Router.navigate('landing');
  });

  // Bottom nav active state sync (section switching handled by router's data-section delegation)
  mobileBottomNav?.querySelectorAll('.mbn-item[data-section]').forEach(item => {
    item.addEventListener('click', () => {
      mobileBottomNav.querySelectorAll('.mbn-item').forEach(i => i.classList.remove('active'));
      item.classList.add('active');
    });
  });

  // ── Page init registrations ───────────────────────────────────────────────

  Router.onLoad('landing', () => {
    showBottomNav(false);

    // Feature cards stagger animation
    document.querySelectorAll('.feature-card').forEach((card, i) => {
      card.style.animationDelay = `${i * 0.08}s`;
      card.classList.add('animate-slide-up');
    });

    // Pipeline step hover highlight
    document.querySelectorAll('.pipeline-step').forEach(step => {
      step.addEventListener('mouseenter', () => step.style.transform = 'translateY(-6px) scale(1.04)');
      step.addEventListener('mouseleave', () => step.style.transform = '');
    });

    // Flipping photo card
    const flipCard = document.getElementById('flipping-card');
    if (flipCard) {
      let isFlipped = false;
      const toggleFlip = () => {
        isFlipped = !isFlipped;
        flipCard.style.transform = isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)';
      };
      flipCard.addEventListener('click', toggleFlip);
      const flipTimer = setInterval(toggleFlip, 5000);
      flipCard._clearFlip = () => clearInterval(flipTimer);
    }
  });

  Router.onLoad('login', () => {
    showBottomNav(false);
    Auth.initLoginPage();
  });

  Router.onLoad('register', () => {
    showBottomNav(false);
    if (typeof Auth.initRegisterPage === 'function') Auth.initRegisterPage();
  });

  Router.onLoad('citizen', () => {
    showBottomNav(true);

    Citizen.init();

    // Reset bottom nav active to "File" tab
    mobileBottomNav?.querySelectorAll('.mbn-item').forEach(i => i.classList.remove('active'));
    document.getElementById('mbn-submit')?.classList.add('active');

    // Section callbacks
    Router.registerSectionCallback('history', () => Citizen.loadMyComplaints());
    Router.registerSectionCallback('notices', () => {
      if (typeof Citizen.loadNotices === 'function') Citizen.loadNotices();
    });

    // Modal close
    document.getElementById('btnModalClose')?.addEventListener('click', () => {
      document.getElementById('complaintModal')?.classList.add('hidden');
    });
    document.getElementById('complaintModal')?.addEventListener('click', (e) => {
      if (e.target.id === 'complaintModal') {
        document.getElementById('complaintModal').classList.add('hidden');
      }
    });
  });

  Router.onLoad('admin', () => {
    showBottomNav(false);
    Admin.init();
  });

  // ── Global utilities ──────────────────────────────────────────────────────

  window.showToast = function (msg, type = 'info') {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = msg;
    el.className   = `toast toast-${type}`;
    el.classList.remove('hidden');
    setTimeout(() => el.classList.add('hidden'), 3500);
  };

  window.showLoading = function (show) {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) overlay.classList.toggle('hidden', !show);
  };

  // ESC closes modal
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.getElementById('complaintModal')?.classList.add('hidden');
    }
  });

  // ── Start the SPA ─────────────────────────────────────────────────────────
  Router.init();

})();
