/**
 * ai.js — Real-time AI analysis panel on the complaint form.
 * Debounces textarea input and calls the analysis API.
 */

const AiPanel = (() => {
  let _debounceTimer = null;
  const DEBOUNCE_MS = 700;

  const PRIORITY_COLORS = {
    CRITICAL: '#ef4444',
    HIGH:     '#f59e0b',
    MEDIUM:   '#4f8ef7',
    LOW:      '#10b981',
  };

  const LANG_FLAGS = {
    en:       '🇬🇧',
    hi:       '🇮🇳',
    hinglish: '🇮🇳',
    mr:       '🇮🇳',
    te:       '🇮🇳',
    ta:       '🇮🇳',
    bn:       '🇮🇳',
  };

  const LANG_NAMES = {
    en:       'English',
    hi:       'Hindi',
    hinglish: 'Hinglish',
    mr:       'Marathi',
    te:       'Telugu',
    ta:       'Tamil',
    bn:       'Bengali',
  };

  function _setSpinner(on) {
    const el = document.getElementById('aiSpinner');
    if (el) el.style.opacity = on ? '1' : '0';
  }

  function _updatePanel(result) {
    const langEl  = document.getElementById('aiLang');
    const catEl   = document.getElementById('aiCategory');
    const priEl   = document.getElementById('aiPriority');
    const dupEl   = document.getElementById('aiDuplicate');

    if (!langEl) return;

    const flag    = LANG_FLAGS[result.language]  || '🌐';
    const langName= LANG_NAMES[result.language]  || result.language;

    langEl.textContent  = `${flag} ${langName}`;
    catEl.textContent   = result.category   || '—';
    dupEl.textContent   = result.is_duplicate ? '⚠️ Possible duplicate detected' : '✅ Unique';

    if (result.priority) {
      priEl.textContent    = result.priority;
      priEl.style.color    = PRIORITY_COLORS[result.priority] || 'inherit';
      priEl.style.fontWeight = '700';
    }

    // Store result for form submission
    Store.set('complaintDraft', {
      ...Store.get('complaintDraft'),
      aiAnalysis: result,
    });
  }

  async function analyze(text) {
    if (!text || text.trim().length < 10) return;

    _setSpinner(true);
    try {
      const result = await Api.ai.analyze(text);
      _updatePanel(result);
    } catch (err) {
      console.error('AI Analysis failed:', err);
    } finally {
      _setSpinner(false);
    }
  }

  function attach(textareaId) {
    const ta = document.getElementById(textareaId);
    if (!ta) return;
    ta.addEventListener('input', () => {
      clearTimeout(_debounceTimer);
      _debounceTimer = setTimeout(() => analyze(ta.value), DEBOUNCE_MS);
    });
  }

  return { attach, analyze };
})();
